# Databricks notebook source
# MAGIC %md
# MAGIC 	Day 2(21th-jan):- a) explore on delta table version history
# MAGIC 					  b) code restructuring to rename multiple columns
# MAGIC
# MAGIC 	task-2.SQL DB connection in databricks		 				
# MAGIC
# MAGIC 	steps :
# MAGIC 			
# MAGIC 			1. create a table in azure sql
# MAGIC 			2. read this sql table in databricks and create dataframe
# MAGIC 			3. perform any transformation in pyspark
# MAGIC 			4. write this dataframe to format as delta (use SaveAsTable)
# MAGIC 			5. same output  write it to azure SQL
# MAGIC
# MAGIC 			
# MAGIC 			https://subscription.packtpub.com/book/data/9781789809718/6/ch06lvl1sec57/versioning-in-delta-tables
# MAGIC
# MAGIC 			https://medium.com/@prachikushwah/data-versioning-using-time-travel-feature-5a5bde2c5e3
# MAGIC
# MAGIC 			https://docs.delta.io/latest/api/python/spark/index.html
# MAGIC
# MAGIC 			https://docs.databricks.com/en/delta/history.html
# MAGIC
# MAGIC 			https://kontext.tech/article/1175/introduction-to-delta-lake-with-pyspark
# MAGIC
# MAGIC 			https://learn.microsoft.com/en-us/azure/databricks/connect/external-systems/sql-server

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### **`delta table version history`**

# COMMAND ----------

# MAGIC %fs ls "abfss://container@storageaccount.dfs.core.windows.net/tulasi/"

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC drop table if exists transactions;
# MAGIC
# MAGIC CREATE TABLE Transactions (
# MAGIC     TransactionID INT PRIMARY KEY,
# MAGIC     Amount DECIMAL(10, 2),
# MAGIC     TransactionDate DATE,
# MAGIC     CustomerID VARCHAR(10),
# MAGIC     TransactionType VARCHAR(10)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO Transactions (TransactionID, Amount, TransactionDate, CustomerID, TransactionType)
# MAGIC VALUES
# MAGIC (1001, 250.00, '2025-01-01', 'C001', 'Credit'),
# MAGIC (1002, 350.00, '2025-01-02', 'C002', 'Debit'),
# MAGIC (1003, 450.00, '2025-01-03', 'C003', 'Credit'),
# MAGIC (1004, 200.00, '2025-01-04', 'C004', 'Debit'),
# MAGIC (1005, 300.00, '2025-01-05', 'C005', 'Credit'),
# MAGIC (1006, 500.00, '2025-01-06', 'C006', 'Debit'),
# MAGIC (1007, 600.00, '2025-01-07', 'C007', 'Credit'),
# MAGIC (1008, 700.00, '2025-01-08', 'C008', 'Debit'),
# MAGIC (1009, 150.00, '2025-01-09', 'C009', 'Credit'),
# MAGIC (1010, 250.00, '2025-01-10', 'C010', 'Debit'),
# MAGIC (1011, 350.00, '2025-01-11', 'C011', 'Credit'),
# MAGIC (1012, 400.00, '2025-01-12', 'C012', 'Debit'),
# MAGIC (1013, 450.00, '2025-01-13', 'C013', 'Credit'),
# MAGIC (1014, 500.00, '2025-01-14', 'C014', 'Debit'),
# MAGIC (1015, 600.00, '2025-01-15', 'C015', 'Credit'),
# MAGIC (1016, 700.00, '2025-01-16', 'C016', 'Debit'),
# MAGIC (1017, 250.00, '2025-01-17', 'C017', 'Credit'),
# MAGIC (1018, 350.00, '2025-01-18', 'C018', 'Debit'),
# MAGIC (1019, 450.00, '2025-01-19', 'C019', 'Credit'),
# MAGIC (1020, 500.00, '2025-01-20', 'C020', 'Debit'),
# MAGIC (1021, 600.00, '2025-01-21', 'C021', 'Credit'),
# MAGIC (1022, 700.00, '2025-01-22', 'C022', 'Debit'),
# MAGIC (1023, 150.00, '2025-01-23', 'C023', 'Credit'),
# MAGIC (1024, 250.00, '2025-01-24', 'C024', 'Debit'),
# MAGIC (1025, 350.00, '2025-01-25', 'C025', 'Credit'),
# MAGIC (1026, 400.00, '2025-01-26', 'C026', 'Debit'),
# MAGIC (1027, 450.00, '2025-01-27', 'C027', 'Credit'),
# MAGIC (1028, 500.00, '2025-01-28', 'C028', 'Debit'),
# MAGIC (1029, 600.00, '2025-01-29', 'C029', 'Credit'),
# MAGIC (1030, 700.00, '2025-01-30', 'C030', 'Debit'),
# MAGIC (1031, 250.00, '2025-01-31', 'C031', 'Credit'),
# MAGIC (1032, 350.00, '2025-02-01', 'C032', 'Debit'),
# MAGIC (1033, 450.00, '2025-02-02', 'C033', 'Credit'),
# MAGIC (1034, 200.00, '2025-02-03', 'C034', 'Debit'),
# MAGIC (1035, 300.00, '2025-02-04', 'C035', 'Credit'),
# MAGIC (1036, 500.00, '2025-02-05', 'C036', 'Debit'),
# MAGIC (1037, 600.00, '2025-02-06', 'C037', 'Credit'),
# MAGIC (1038, 700.00, '2025-02-07', 'C038', 'Debit'),
# MAGIC (1039, 150.00, '2025-02-08', 'C039', 'Credit'),
# MAGIC (1040, 250.00, '2025-02-09', 'C040', 'Debit'),
# MAGIC (1041, 350.00, '2025-02-10', 'C041', 'Credit'),
# MAGIC (1042, 400.00, '2025-02-11', 'C042', 'Debit'),
# MAGIC (1043, 450.00, '2025-02-12', 'C043', 'Credit'),
# MAGIC (1044, 500.00, '2025-02-13', 'C044', 'Debit'),
# MAGIC (1045, 600.00, '2025-02-14', 'C045', 'Credit'),
# MAGIC (1046, 700.00, '2025-02-15', 'C046', 'Debit'),
# MAGIC (1047, 250.00, '2025-02-16', 'C047', 'Credit'),
# MAGIC (1048, 350.00, '2025-02-17', 'C048', 'Debit'),
# MAGIC (1049, 450.00, '2025-02-18', 'C049', 'Credit'),
# MAGIC (1050, 500.00, '2025-02-19', 'C050', 'Debit');

# COMMAND ----------

transaction_df = spark.table("adls.tulasi.transactions")

# COMMAND ----------

transaction_df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("path", "abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH") \
    .saveAsTable("adls.tulasi.transactions")

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history "abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH"

# COMMAND ----------

spark.read \
    .format("delta") \
    .option("VersionAsof", 0) \
    .load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH") \
    .display()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM DELTA.`abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH` VERSION AS OF 0

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH`

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from adls.tulasi.transactions

# COMMAND ----------

# MAGIC %sql
# MAGIC RESTORE TABLE adls.tulasi.transactions VERSION AS OF 0

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history adls.tulasi.transactions

# COMMAND ----------

# MAGIC %sql
# MAGIC restore adls.tulasi.transactions VERSION AS OF 13

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from adls.tulasi.transactions

# COMMAND ----------

# %sql
# SELECT * 
# FROM delta.`abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH` 
# TIMESTAMP AS OF current_timestamp()

# COMMAND ----------

from delta.tables import DeltaTable

delta_table = DeltaTable.forPath(spark, "abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH")

# Create a DataFrame for the new data to be inserted
new_data = spark.createDataFrame([
    (1051, 600.00, '2025-02-20', 'C051', 'Credit'),
    (1052, 700.00, '2025-02-21', 'C052', 'Debit'),
    (1053, 250.00, '2025-02-22', 'C053', 'Credit'),
    (1054, 350.00, '2025-02-23', 'C054', 'Debit')
], ["TransactionID", "Amount", "TransactionDate", "CustomerID", "TransactionType"])

# Insert the new data into the Delta Table
delta_table.alias("t").merge(
    new_data.alias("new"),
    "t.TransactionID = new.TransactionID"
).whenNotMatchedInsertAll().execute()

# COMMAND ----------

transaction_df_v2 = spark.read \
    .format("delta") \
    .load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH")

transaction_df_v2.display()

# COMMAND ----------

# Updating a specific transaction's Amount where TransactionID = 1001
delta_table.update(
    condition = "TransactionID = 1001",
    set = { "Amount": "275.00" }
)

# Changing the TransactionType for TransactionID = 1010
delta_table.update(
    condition = "TransactionID = 1010",
    set = { "TransactionType": "'Credit'" }
)

# Updating CustomerID and Amount for TransactionID = 1040
delta_table.update(
    condition = "TransactionID = 1040",
    set = { "CustomerID": "'C060'", "Amount": "275.00" }
)

# Updating the TransactionDate for TransactionID = 1036
delta_table.update(
    condition = "TransactionID = 1036",
    set = { "TransactionDate": "'2025-02-06'" }
)


# COMMAND ----------

transaction_df_v3 = spark.read \
    .format("delta") \
    .load("abfss://abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH") \
    .display()

# COMMAND ----------

# Updating a specific transaction's Amount where TransactionID = 1001
delta_table.update(
    condition = "TransactionID = 1001",
    set = { "Amount": "275.00" }
)

# Changing the TransactionType for TransactionID = 1010
delta_table.update(
    condition = "TransactionID = 1010",
    set = { "TransactionType": "'Credit'" }
)

# Updating CustomerID and Amount for TransactionID = 1040
delta_table.update(
    condition = "TransactionID = 1040",
    set = { "CustomerID": "'C060'", "Amount": "275.00" }
)

# Updating the TransactionDate for TransactionID = 1036
delta_table.update(
    condition = "TransactionID = 1036",
    set = { "TransactionDate": "'2025-02-06'" }
)


# COMMAND ----------

transaction_df_v4 = spark.read \
    .format("delta") \
    .load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH")\
    .display()

# COMMAND ----------

# Update all Debit transactions to Credit
delta_table.update(
    condition = "TransactionType = 'Debit'",
    set = { "TransactionType": "'Credit'" }
)

# Increasing the amount by 10% for Credit transactions
delta_table.update(
    condition = "TransactionType = 'Credit'",
    set = { "Amount": "Amount * 1.10" }
)


# COMMAND ----------

transaction_df_v5 = spark.read \
    .format("delta") \
    .load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH") \
    .display()

# COMMAND ----------

# Deleting a specific transaction with TransactionID = 1054
delta_table.delete("TransactionID = 1054")

# COMMAND ----------

transaction_df_v6 = spark.read \
    .format("delta") \
    .load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH") \

transaction_df_v6.display()

# COMMAND ----------

transaction_df_v6.createOrReplaceTempView("transactions_view")

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history delta.`abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH`

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from delta.`abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH` version as of 14

# COMMAND ----------

df_history = DeltaTable.forPath(spark, "abfss://container@storageaccount.dfs.core.windows.net/tulasi/transactions_DFVH")
df_history.history().display()

# COMMAND ----------

# MAGIC %md
# MAGIC Reading, Code restructuring another file

# COMMAND ----------

spark.read \
  .format("csv") \
  .option("header", "true") \
  .option("quote", "'") \
  .load("abfss://container@storageaccount.dfs.core.windows.net/anusha/Quality_of_Life.csv").display()

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, FloatType

qol_schema = StructType([
    StructField("country", StringType(), True),
    StructField("Purchasing_Power_Value", FloatType(), True),
    StructField("Purchasing_Power_Category", StringType(), True),
    StructField("Safety_Value", FloatType(), True),
    StructField("Safety_Category", StringType(), True),
    StructField("Health_Care_Value", FloatType(), True),
    StructField("Health_Care_Category", StringType(), True),
    StructField("Climate_Value", FloatType(), True),
    StructField("Climate_Category", StringType(), True),
    StructField("Cost_of_Living_Value", FloatType(), True),
    StructField("Cost_of_Living_Category", StringType(), True),
    StructField("Property_Price_to_Income_Value", StringType(), True),
    StructField("Property_Price_to_Income_Category", StringType(), True),
    StructField("Traffic_Commute_Time_Value", FloatType(), True),
    StructField("Traffic_Commute_Time_Category", StringType(), True),
    StructField("Pollution_Value", FloatType(), True),
    StructField("Pollution_Category", StringType(), True),
    StructField("Quality_of_Life_Value", StringType(), True),
    StructField("Quality_of_Life_Category", StringType(), True)
])

qol_df = spark.read \
  .format("csv") \
  .option("header", "true") \
  .option("quote", "'") \
  .schema(qol_schema) \
  .load("abfss://container@storageaccount.dfs.core.windows.net/anusha/Quality_of_Life.csv")

for col in qol_df.columns:
    qol_df = qol_df.withColumnRenamed(col, col.replace(" ", "_"))

display(qol_df)

# COMMAND ----------

qol_df.printSchema()

# COMMAND ----------

qol_df.write \
  .format("delta") \
  .mode("overwrite") \
  .option("path", "abfss://container@storageaccount.dfs.core.windows.net/tulasi/quality_of_life_delta") \
  .saveAsTable("adls.tulasi.quality_of_life_delta")

# COMMAND ----------

for col in qol_df.schema:
    print(col.name + " " + str(col.dataType))

# COMMAND ----------

# MAGIC %md
# MAGIC     country StringType()
# MAGIC     Purchasing_Power_Value FloatType()
# MAGIC     Purchasing_Power_Category StringType()
# MAGIC     Safety_Value FloatType()
# MAGIC     Safety_Category StringType()
# MAGIC     Health_Care_Value FloatType()
# MAGIC     Health_Care_Category StringType()
# MAGIC     Climate_Value FloatType()
# MAGIC     Climate_Category StringType()
# MAGIC     Cost_of_Living_Value FloatType()
# MAGIC     Cost_of_Living_Category StringType()
# MAGIC     Property_Price_to_Income_Value StringType()
# MAGIC     Property_Price_to_Income_Category StringType()
# MAGIC     Traffic_Commute_Time_Value FloatType()
# MAGIC     Traffic_Commute_Time_Category StringType()
# MAGIC     Pollution_Value FloatType()
# MAGIC     Pollution_Category StringType()
# MAGIC     Quality_of_Life_Value StringType()
# MAGIC     Quality_of_Life_Category StringType()

# COMMAND ----------

from delta.tables import DeltaTable

spark.sql("DESCRIBE HISTORY delta.`abfss://container@storageaccount.dfs.core.windows.net/anusha/Quality_of_Life_newdelta.delta`")

 
delta_table = DeltaTable.forPath(spark,"abfss://container@storageaccount.dfs.core.windows.net/anusha/Quality_of_Life_newdelta.delta")
 
history = delta_table.history()
display(history)
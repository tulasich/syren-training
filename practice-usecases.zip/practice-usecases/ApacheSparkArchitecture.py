# Databricks notebook source
# MAGIC %md
# MAGIC https://www.youtube.com/watch?v=iXVIPQEGZ9Y

# COMMAND ----------

spark.conf.set("spark.databricks.io.cashe.enabled", False)

# COMMAND ----------

total_size = 0

for x in dbutils.fs.ls("/databricks-datasets/nyctaxi/tripdata/yellow/"):
    print(x.name, "-", round(x.size/(1024*1024)))

print(round(total_size), "MB")

# COMMAND ----------

# MAGIC %md
# MAGIC 2009 data

# COMMAND ----------

spark.read \
  .csv("/databricks-datasets/nyctaxi/tripdata/yellow/yellow_tripdata_2009*") \
  .count()

# COMMAND ----------

# MAGIC %md
# MAGIC 2009 and 2010 data

# COMMAND ----------

spark.read \
    .csv("/databricks-datasets/nyctaxi/tripdata/yellow/yellow_tripdata_{2009,2010}*") \
    .count()

# COMMAND ----------

# MAGIC %md
# MAGIC Reading single file

# COMMAND ----------

spark \
  .read \
  .csv("/databricks-datasets/nyctaxi/tripdata/yellow/yellow_tripdata_2009-12.csv.gz") \
  .count()
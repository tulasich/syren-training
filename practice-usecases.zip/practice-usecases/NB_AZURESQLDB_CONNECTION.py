# Databricks notebook source
# MAGIC %md
# MAGIC ### SQL DB CONNECTION

# COMMAND ----------

remote_table = (spark.read
  .format("sqlserver")
  .option("host", "databaseName.database.windows.net")
  .option("user", "username")
  .option("password", "password")
  .option("database", "databaseName")
  .option("dbtable", "[dbo].[first]") # (if schemaName not provided, default to "dbo")
  .load()
)

# COMMAND ----------

remote_table.display()

# COMMAND ----------

# # Define SQL Server JDBC URL and connection properties
# jdbc_url = "jdbc:sqlserver://localhost:1433;databaseName=dbo"
# connection_properties = {
#     "user": "username",
#     "password": "password",
#     "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
# }
 
# # Read data from SQL Server table into DataFrame
# df = spark.read.jdbc(
#     url=jdbc_url,
#     table="first",
#     properties=connection_properties
# )
 
# # Show the DataFrame content
# display(df)

# COMMAND ----------

import random

def random_country():
    return random.choice(["India", "USA", "China", "Japan", "Germany", "France", "Italy", "Spain", "UK", "Canada"])

random_country_udf = udf(random_country, StringType())

# COMMAND ----------

remote_table = remote_table.withColumn("country", random_country_udf())

# COMMAND ----------

remote_table.display()

# COMMAND ----------

remote_table.write.format("delta").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/first_newdelta")

# COMMAND ----------

(remote_table.write 
    .format("sqlserver")
    .option("host", "databaseName.database.windows.net")
    .option("user", "username")
    .option("password", "password")
    .option("database", "databaseName")
    .option("dbtable", "[dbo].[first_new]") # (if schemaName not provided, default to "dbo")
    .mode("overwrite")
    .save()
)
# Databricks notebook source
# MAGIC %md
# MAGIC     Day 3(22th-jan):-
# MAGIC         
# MAGIC         a)explore on databricks secret scopes
# MAGIC         b)finish code restructuring to rename multiple columns
# MAGIC         c)explore on Azure Data factory (basics)
# MAGIC               1.linked service 
# MAGIC               2.datasets
# MAGIC               3.different activities
# MAGIC               4.types of triggers (why and when its used)					 
# MAGIC         d)explore and practice other pyspark functions like explode 
# MAGIC             collect list ,array joins etc etc ...(perform each function)
# MAGIC
# MAGIC         https://learn.microsoft.com/en-us/azure/databricks/security/secrets/

# COMMAND ----------

# MAGIC %md
# MAGIC ### databricks secret scopes

# COMMAND ----------

from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

w.secrets.create_scope(scope='scope_tul')

w.secrets.put_secret("scope_tul", "username", string_value = "username")

w.secrets.put_secret("scope_tul", "password", string_value = "password")

# COMMAND ----------

username = dbutils.secrets.get(scope="scope_tul", key="username")
print(username)

password = dbutils.secrets.get(scope="scope_tul", key="password")
print(password)

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list("scope_tul")

# COMMAND ----------

df = (
    spark.read 
        .format("sqlserver") 
        .option("host", "databaseName.database.windows.net")
        .option("user", username)
        .option("password", password)
        .option("database", "databaseName")
        .option("dbtable", "dbo.siva_employees")
        .load()
)

# COMMAND ----------

w.secrets.list_acls('scope_tul')

# COMMAND ----------

from databricks.sdk.service import workspace

w.secrets.put_acl(
    scope='scope_tul', 
    permission=workspace.AclPermission.READ, 
    principal='anusha.p@company.com'
)

# COMMAND ----------

# MAGIC %md
# MAGIC alternatively

# COMMAND ----------

import requests

# Set Databricks instance and token
databricks_instance = "adb-678318348142550.10.azuredatabricks.net"
token = "dapi36ed0dbff9208b067bbf551d04a4b3bf"
headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

response_scope = requests.post(
    f"https://{databricks_instance}/api/2.0/secrets/scopes/create",
    headers=headers,
    json={"scope": "my-scope"}
)
print(response_scope.status_code, response_scope.json())

# Add a username secret
response_username = requests.post(
    f"https://{databricks_instance}/api/2.0/secrets/put",
    headers=headers,
    json={"scope": "my-scope", "key": "username", "string_value": "username"}
)
print(response_username.status_code, response_username.json())

# Add a password secret
response_password = requests.post(
    f"https://{databricks_instance}/api/2.0/secrets/put",
    headers=headers,
    json={"scope": "my-scope", "key": "password", "string_value": "password"}
)
print(response_password.status_code, response_password.json())

# COMMAND ----------

# MAGIC %md
# MAGIC ` B) CODE RESTRUCTURING `
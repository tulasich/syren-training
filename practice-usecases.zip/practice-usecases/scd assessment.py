# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import *
from delta.tables import *

# COMMAND ----------

df = spark.read.format('csv').option('header',True).schema(schema).load('dbfs:/FileStore/tables/scd_file.csv')
df.display()

# COMMAND ----------

p = df.count()
for colu in df.columns:
    k = (df.groupBy(colu).count()).count()
    if(p==k):
        print('Primary Key is',colu)
        break

# COMMAND ----------

df = df.withColumn("ParticipatingCountries",split(df['ParticipatingCountries'],','))

# COMMAND ----------

df.display()

# COMMAND ----------

df  = df.select('country_cd','hscode','shortname','longname','tarifftype','duty',explode(df.ParticipatingCountries),'addvaloremrate','perunit','unitcode','calculationmethod','formulatext','TariffCodeID')

# COMMAND ----------

df.display()

# COMMAND ----------

df = df.withColumnRenamed('col','ParticipatingCountries')
df.display()

# COMMAND ----------

df.display()

# COMMAND ----------

schema = StructType([
    StructField('country_cd',StringType()),
    StructField('hscode',IntegerType()),
    StructField('shortname',StringType()),
    StructField('longname',StringType()),
    StructField('tarifftype',StringType()),
    StructField('duty',StringType()),
    StructField('ParticipatingCountries',StringType()),
    StructField('addvaloremrate',IntegerType()),
    StructField('perunit',IntegerType()),
    StructField('unitcode',IntegerType()),
    StructField('calculationmethod',StringType()),
    StructField('formulatext',StringType()),
    StructField('TariffCodeID',IntegerType()),
    StructField('effectivestart_date',TimestampType()),
    StructField('effectiveend_date',StringType()),
])


df1 = spark.createDataFrame([],schema = schema)
df1.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC create database poc

# COMMAND ----------

df1=spark.read.format("delta").load("dbfs:/FileStore/tables/delta43")

# COMMAND ----------

df1.write.mode('overwrite').saveAsTable('poc.target')

# COMMAND ----------

target = DeltaTable.forPath(spark,'dbfs:/FileStore/tables/delta43')

# COMMAND ----------

target.alias('target').merge(
    source=df.alias('source'),
    condition='source.shortname is NULL'
).whenMatchedUpdate(
    set={}
).whenNotMatchedInsert(
    values={
        'country_cd' : 'source.country_cd',
        'hscode' : 'source.hscode',
        'shortname': 'source.shortname',
        'longname' : 'source.longname',
        'tarifftype': 'source.tarifftype',
        'duty' : 'source.duty',
        'ParticipatingCountries':'source.ParticipatingCountries',
        'addvaloremrate': 'source.addvaloremrate',
        'perunit': 'source.perunit',
        'unitcode': 'source.unitcode',
        'calculationmethod':'source.calculationmethod',
        'formulatext':'source.formulatext',
        'TariffCodeID':'TariffCodeID',
        'effectivestart_date':'current_timestamp()',
        'effectiveend_date':'"9999-12-31T23:59:59"'
    }
).execute()

# COMMAND ----------

target.toDF().display()

# COMMAND ----------

schema1 = StructType([
    StructField('country_cd',StringType()),
    StructField('hscode',IntegerType()),
    StructField('shortname',StringType()),
    StructField('longname',StringType()),
    StructField('tarifftype',StringType()),
    StructField('duty',StringType()),
    StructField('ParticipatingCountries',StringType()),
    StructField('addvaloremrate',IntegerType()),
    StructField('perunit',IntegerType()),
    StructField('unitcode',IntegerType()),
    StructField('calculationmethod',StringType()),
    StructField('formulatext',StringType()),
    StructField('TariffCodeID',IntegerType())])

# COMMAND ----------

source = spark.read.format("csv").option('header',True).schema(schema1).load("dbfs:/FileStore/tables/updated.csv")
source.display()

# COMMAND ----------

source = source.withColumn("ParticipatingCountries",split(source['ParticipatingCountries'],','))
source.display()

# COMMAND ----------

source  = source.select('country_cd','hscode','shortname','longname','tarifftype','duty',explode(source.ParticipatingCountries),'addvaloremrate','perunit','unitcode','calculationmethod','formulatext','TariffCodeID')

# COMMAND ----------

source = source.withColumnRenamed('col','ParticipatingCountries')
source.display()

# COMMAND ----------

#country_cd,hscode,shortname,ParticipatingCountries

# COMMAND ----------

targetDF = target.toDF()

# COMMAND ----------

joinDF = source.join(targetDF,(source.country_cd == targetDF.country_cd) & (source.hscode == targetDF.hscode) & (source.shortname == targetDF.shortname) & 
                     (source.ParticipatingCountries == targetDF.ParticipatingCountries)&(targetDF.effectiveend_date=='9999-12-31T23:59:59') ,'left_outer')\
                 .select(source['*'],\
                         targetDF.country_cd.alias('tcountry_cd'),\
                         targetDF.hscode.alias('thscode'),\
                         targetDF.shortname.alias('tshortname'),\
                         targetDF.longname.alias('tlongname'),\
                         targetDF.tarifftype.alias('ttarifftype'),\
                         targetDF.duty.alias('tduty'),\
                         targetDF.ParticipatingCountries.alias('tParticipatingCountries'),\
                         targetDF.addvaloremrate.alias('taddvaloremrate'),\
                         targetDF.perunit.alias('tperunit'),\
                         targetDF.unitcode.alias('tunitcode'),\
                         targetDF.calculationmethod.alias('tcalculationmethod'),\
                         targetDF.formulatext.alias('tformulatext'),\
                         targetDF.TariffCodeID.alias('tTariffCodeID'))
joinDF.display()

# COMMAND ----------


filterdf = joinDF.filter(xxhash64(joinDF.longname,joinDF.tarifftype,joinDF.duty,joinDF.perunit,
                                  joinDF.addvaloremrate,joinDF.unitcode,joinDF.calculationmethod,joinDF.formulatext,joinDF.TariffCodeID)!=
                         xxhash64(joinDF.tlongname,joinDF.ttarifftype,joinDF.tduty,joinDF.tperunit,
                                  joinDF.taddvaloremrate,joinDF.tunitcode,joinDF.tcalculationmethod,joinDF.tformulatext,joinDF.tTariffCodeID))
filterdf.display()

# COMMAND ----------

mergeDF = filterdf.withColumn('mergehash',xxhash64(filterdf.country_cd,filterdf.hscode,filterdf.shortname,filterdf.ParticipatingCountries))
mergeDF.display()

# COMMAND ----------

dummyDF = filterdf.filter('thscode is not null').withColumn('mergekey',lit(None))
dummyDF.display()

# COMMAND ----------

scdDF = mergeDF.union(dummyDF)
scdDF.display()

# COMMAND ----------

target.alias('target').merge(
    source=scdDF.alias('source'),
    condition='xxhash64(target.country_cd,target.hscode,target.shortname,target.ParticipatingCountries)==source.mergehash and target.effectiveend_date = "9999-12-31T23:59:59"'
).whenMatchedUpdate(
    set={
        'effectiveend_date':'current_timestamp()'
    }
).whenNotMatchedInsert(
    values={
        'country_cd' : 'source.country_cd',
        'hscode' : 'source.hscode',
        'shortname': 'source.shortname',
        'longname' : 'source.longname',
        'tarifftype': 'source.tarifftype',
        'duty' : 'source.duty',
        'ParticipatingCountries':'source.ParticipatingCountries',
        'addvaloremrate': 'source.addvaloremrate',
        'perunit': 'source.perunit',
        'unitcode': 'source.unitcode',
        'calculationmethod':'source.calculationmethod',
        'formulatext':'source.formulatext',
        'TariffCodeID':'TariffCodeID',
        'effectivestart_date':'current_timestamp()',
        'effectiveend_date':'"9999-12-31T23:59:59"'
    }
).execute()

# COMMAND ----------

target.toDF().display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select effectivestart_date,effectiveend_date,count(*) from poc.target group by all

# COMMAND ----------


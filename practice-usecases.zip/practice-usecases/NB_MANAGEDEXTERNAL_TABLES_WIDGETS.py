# Databricks notebook source
# MAGIC %md
# MAGIC     day 5:(24th-jan):-
# MAGIC         a)explore on difference between managed and external tables in databricks
# MAGIC         b)create managed and external delta tables in databricks 
# MAGIC         c)explore on what is mean by incremental load (theory)
# MAGIC         d)joins practice in pyspark  (left , left -anti, left-semi  etc.) # JOINS IN DAY 4 SHEET
# MAGIC
# MAGIC     2:30 meet - real time scenarios demo
# MAGIC         a) dbutils widgets
# MAGIC         b) jira exploring

# COMMAND ----------

# MAGIC %sql
# MAGIC use adls.tulasi

# COMMAND ----------

tables = spark.catalog.listTables()
for table in tables:
    print(table.name, table.tableType)

# COMMAND ----------

# MAGIC %md
# MAGIC     customer_append_delta EXTERNAL
# MAGIC     customer_delta EXTERNAL
# MAGIC     customer_orders MANAGED
# MAGIC     customer_parquet EXTERNAL
# MAGIC     emp_delta MANAGED
# MAGIC     employees_parquet EXTERNAL
# MAGIC     my_external_table EXTERNAL
# MAGIC     my_managed_delta_table MANAGED
# MAGIC     ntv MANAGED
# MAGIC     pickles MANAGED
# MAGIC     pizza_names MANAGED
# MAGIC     pizza_toppings MANAGED
# MAGIC     products MANAGED
# MAGIC     runner_orders MANAGED
# MAGIC     runners MANAGED
# MAGIC     sample_csv EXTERNAL

# COMMAND ----------

# MAGIC %sql
# MAGIC create table adls.tulasi.my_external_table
# MAGIC using parquet
# MAGIC location "abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.parquet"

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table adls.tulasi.cust_ord
# MAGIC clone customer_orders

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table cust_delta
# MAGIC clone adls.tulasi.customer_delta

# COMMAND ----------

# MAGIC %md
# MAGIC #### DBUTILS WIDGETS

# COMMAND ----------

dbutils.help()

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

# MAGIC %md
# MAGIC dbutils.widgets.combobox allows users to enter names which are not present in the choices list while dropdown DOESNT ALLOW additional inputs and accepts to be chosen from the dropdown menu

# COMMAND ----------

dbutils.widgets.combobox(name = "new_box", defaultValue = "apple", choices = ["a", "b", "c"])

# COMMAND ----------

dbutils.widgets.dropdown(name = "some_guy", defaultValue = "jeremy", choices = ["jeremy", "nic", "noc"]) 

# COMMAND ----------

dbutils.widgets.multiselect(name = "natyam", defaultValue = "kathakali", choices = ["bharatanatyam", "garba", "kathakali", "kathak", "kuchipudi", "salsa"])

# COMMAND ----------

dbutils.widgets.text(name = "Iktara", defaultValue = "tum", label = "Kon hai")

# COMMAND ----------

dbutils.widgets.get("Iktara")

# COMMAND ----------

dbutils.widgets.get("natyam")

# COMMAND ----------

dbutils.widgets.get("some_guy")

# COMMAND ----------

dbutils.widgets.getArgument("ne+box", "error: widget doesn't exist")

# COMMAND ----------

dbutils.widgets.remove("ne+box")

# COMMAND ----------

dbutils.widgets.remove("new_box")

# COMMAND ----------

dbutils.widgets.removeAll()
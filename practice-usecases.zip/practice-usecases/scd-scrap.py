# Databricks notebook source
# MAGIC %md
# MAGIC %md
# MAGIC create source table - empno, ename, deptno, sal, comm with its respective values
# MAGIC
# MAGIC create target table - same columns but the table is empty - all null values
# MAGIC
# MAGIC rename source tables columns in the dataframe to represent they're source tables - eg: empno_src, similarly for target table
# MAGIC
# MAGIC insert the current source table values into target table using mode append - renaming columns as per table column names
# MAGIC
# MAGIC now, update the initial table we started with, i.e, employee_source

# COMMAND ----------

from pyspark.sql.functions import col

# Sample source and target data
source_data = [
    (1, "John", "USA"),
    (2, "Alice", "UK"),
    (3, "Bob", "Canada")
]

target_data = [
    (1, "John", "India"),  # John is in India in the target, needs to be updated
    (2, "Alice", "USA"),   # Alice's country is different, needs to be updated
    (4, "Tom", "Germany")  # Tom doesn't exist in source, no change
]

# Define schema for both datasets
columns = ["id", "name", "country"]

# Create DataFrames
source_df = spark.createDataFrame(source_data, columns)
target_df = spark.createDataFrame(target_data, columns)

# Show the source and target dataframes
print("Source Data:")
source_df.show()

print("Target Data:")
target_df.show()

# Performing the SCD Type 1 logic (overwriting the records in the target with the source)
# For SCD1, we just join the source with target on the primary key (id) and update the target data
updated_target_df = target_df.alias('target').join(source_df.alias('source'), "id", "left_outer") \
    .select(
        col('source.id').alias('id'),
        col('source.name').alias('name'),
        col('source.country').alias('country')
    ).union(
        target_df.subtract(source_df)
    )

# Show the updated target dataframe
print("Updated Target Data:")
updated_target_df.show()

%sql
use adls.tulasi
%sql

-- Source Table (EMP):

DROP TABLE IF EXISTS EMP;
DROP TABLE IF EXISTS emp_dim;

CREATE TABLE EMP (
    EMPNO INT PRIMARY KEY,
    ENAME VARCHAR(50),
    DEPTNO INT,
    SAL DECIMAL(10, 2),
    COMM DECIMAL(10, 2)
);

-- Target Table (EMP_DIM):

CREATE TABLE EMP_DIM (
    EMPNO INT PRIMARY KEY,
    ENAME VARCHAR(50),
    DEPTNO INT,
    SAL DECIMAL(10, 2),
    COMM DECIMAL(10, 2),
    LAST_UPDATED_DATE TIMESTAMP
);
# Process Overview:

# Step 1: Identify changes by comparing the EMP source table with the EMP_DIM target table.
# Step 2: For any records where the data has changed, update the target table (overwrite existing records).
# Step 3: Add a LAST_UPDATED_DATE to track when each record was updated.
%md
###### SQL Implementation:
Here’s a simple SQL process for implementing SCD Type 1:

Insert new records and update changed records: We will use a combination of MERGE and UPDATE SQL statements.
%sql
INSERT INTO EMP (EMPNO, ENAME, DEPTNO, SAL, COMM) VALUES
(7369, 'SMITH', 20, 800.00, NULL),
(7499, 'ALLEN', 30, 1600.00, 300.00),
(7521, 'WARD', 30, 1250.00, 500.00),
(7566, 'JONES', 20, 2975.00, NULL),
(7654, 'MARTIN', 30, 1250.00, 1400.00),
(7698, 'BLAKE', 30, 2850.00, NULL),
(7782, 'CLARK', 10, 2450.00, NULL),
(7788, 'SCOTT', 20, 3000.00, NULL),
(7839, 'KING', 10, 5000.00, NULL),
(7844, 'TURNER', 30, 1500.00, 0.00),
(7876, 'ADAMS', 20, 1100.00, NULL),
(7900, 'JAMES', 30, 950.00, NULL),
(7902, 'FORD', 20, 3000.00, NULL),
(7934, 'MILLER', 10, 1300.00, NULL);
%sql
SELECT * FROM EMP
%sql
SELECT * FROM emp_dim
%sql

-- MERGE [ WITH SCHEMA EVOLUTION ] INTO target_table_name [target_alias]
--    USING source_table_reference [source_alias]
--    ON merge_condition
--    { WHEN MATCHED [ AND matched_condition ] THEN matched_action |
--      WHEN NOT MATCHED [BY TARGET] [ AND not_matched_condition ] THEN not_matched_action |
--      WHEN NOT MATCHED BY SOURCE [ AND not_matched_by_source_condition ] THEN not_matched_by_source_action } [...]

-- matched_action
--  { DELETE |
--    UPDATE SET * |
--    UPDATE SET { column = { expr | DEFAULT } } [, ...] }

-- not_matched_action
--  { INSERT * |
--    INSERT (column1 [, ...] ) VALUES ( expr | DEFAULT ] [, ...] )

-- not_matched_by_source_action
--  { DELETE |
--    UPDATE SET { column = { expr | DEFAULT } } [, ...] }


-- Step 1: Update existing records if there is a change in data.
MERGE INTO EMP_DIM target
USING EMP source
ON (target.EMPNO = source.EMPNO)
WHEN MATCHED AND (
    target.ENAME != source.ENAME OR
    target.DEPTNO != source.DEPTNO OR
    target.SAL != source.SAL OR
    target.COMM != source.COMM
) THEN
    UPDATE SET 
        target.ENAME = source.ENAME,
        target.DEPTNO = source.DEPTNO,
        target.SAL = source.SAL,
        target.COMM = source.COMM,
        target.LAST_UPDATED_DATE = CURRENT_TIMESTAMP;


%sql
-- Step 2: Insert new records that don't exist in the target.
INSERT INTO EMP_DIM (EMPNO, ENAME, DEPTNO, SAL, COMM, LAST_UPDATED_DATE)
SELECT EMPNO, ENAME, DEPTNO, SAL, COMM, CURRENT_TIMESTAMP
FROM EMP
WHERE EMPNO NOT IN (SELECT EMPNO FROM EMP_DIM);
%sql
SELECT * FROM emp_dim
%sql

INSERT INTO emp
VALUES(7778, 'VIVEK', 10, 1980, 200)
%sql

INSERT INTO emp
VALUES(7778, 'JANET', 20, 1780, 250);
%sql
UPDATE emp
SET SAL = 1120
WHERE EMPNO = 7369;

UPDATE emp
SET SAL = 1000
WHERE EMPNO = 7900;
%sql
MERGE INTO EMP_DIM target
USING EMP source
ON (target.EMPNO = source.EMPNO)
WHEN MATCHED then
    UPDATE SET 
        target.ENAME = source.ENAME,
        target.DEPTNO = source.DEPTNO,
        target.SAL = source.SAL,
        target.COMM = source.COMM,
        target.LAST_UPDATED_DATE = CURRENT_TIMESTAMP

when not matched then
    INSERT (EMPNO, ENAME, DEPTNO, SAL, COMM, LAST_UPDATED_DATE)
    VALUES(EMPNO, ENAME, DEPTNO, SAL, COMM, CURRENT_TIMESTAMP);
    
%sql
SELECT * FROM EMP
%sql
SELECT * FROM emp_dim

%sql

drop table if exists merge1;

CREATE TABLE merge1 (
    EMPNO INT PRIMARY KEY,
    ENAME VARCHAR(50),
    DEPTNO INT,
    SAL DECIMAL(10, 2),
    COMM DECIMAL(10, 2)
);

-- Target Table (EMP_DIM):

%sql
insert into merge1
values(7778, "Janet", 3, 3.00, 3.00)
%sql
MERGE INTO EMP_DIM target
USING merge1 source
ON (target.EMPNO = source.EMPNO)
WHEN MATCHED then
    UPDATE SET 
        target.ENAME = source.ENAME,
        target.DEPTNO = source.DEPTNO,
        target.SAL = source.SAL,
        target.COMM = source.COMM,
        target.LAST_UPDATED_DATE = CURRENT_TIMESTAMP

when not matched then
    INSERT (EMPNO, ENAME, DEPTNO, SAL, COMM, LAST_UPDATED_DATE)
    VALUES(EMPNO, ENAME, DEPTNO, SAL, COMM, CURRENT_TIMESTAMP);
    
%sql
select * from merge1
%sql
select * from emp_dim

# COMMAND ----------

# MAGIC %md
# MAGIC ---------

# COMMAND ----------

properties = {
        "host": "databaseName.database.windows.net",
        "user": "username",
        "password": "password",
        "database": "dbname",
    }

# Import source dataset

emp_src_df = spark.read \
    .format("sqlserver") \
    .options(**properties) \
    .option("dbtable", "dbo.employees_source") \
    .load()

# import Target dataset, as of now target has zero rows

emp_tgt_df = spark.read \
    .format("sqlserver") \
    .options(**properties) \
    .option("dbtable", "dbo.employees_target") \
    .load()

# rename source and target DFs columns

emp_src_df = emp_src_df.withColumnRenamed('EMPNO', 'EMPNO_SRC') \
    .withColumnRenamed('SAL', 'SAL_SRC') \
    .withColumnRenamed('ENAME', 'ENAME_SRC') \
    .withColumnRenamed('DEPTNO', 'DEPTNO_SRC') \
    .withColumnRenamed('COMM', 'COMM_SRC')

emp_tgt_df = emp_tgt_df.withColumnRenamed('EMPNO', 'EMPNO_TGT') \
    .withColumnRenamed('SAL', 'SAL_TGT')

emp_src_df.display()
emp_tgt_df.display()

# COMMAND ----------

# Perform Left Outer join on Source and Target DFs

emp_scd_df = emp_src_df.join(emp_tgt_df, emp_src_df.EMPNO_SRC == emp_tgt_df.EMPNO_TGT, how = "left")
emp_scd_df.show()

# COMMAND ----------

# Flag the Records for Insert/Updates

from pyspark.sql.functions import lit
from pyspark.sql import functions as f

scd_df = emp_scd_df.withColumn("INS_FLAG",
        f.when((emp_scd_df.EMPNO_SRC != emp_scd_df.EMPNO_TGT) | emp_scd_df.EMPNO_TGT.isNull(),"Y"). \
        otherwise("NA"))
scd_df.show()

# COMMAND ----------

# Insert records into target
# renaming columns as per table column names

emp_ins = scd_df \
    .select(scd_df["EMPNO_SRC"].alias("EMPNO"),
            scd_df["ENAME_SRC"].alias("ENAME"),
            scd_df["DEPTNO_SRC"].alias("DEPTNO"),
            scd_df["SAL_SRC"].alias("SAL"),
            scd_df["COMM_SRC"].alias("COMM")
    )

emp_ins.write \
    .format("sqlserver") \
    .mode("append") \
    .options(**properties) \
    .option("dbtable", "emp_spark_scd1") \
    .save()

# COMMAND ----------

# Import Source and Target Dataset

emp_src1 = spark.read \
    .format("sqlserver") \
    .options(**properties) \
    .option("dbtable", "dbo.employees_source") \
    .load()

emp_tgt1 = spark.read \
    .format("sqlserver") \
    .options(**properties) \
    .option("dbtable", "dbo.emp_spark_scd1") \
    .load()

emp_src1.display()
emp_tgt1.display()

# COMMAND ----------

# Combine Datasets and Insert/Update Flagging

from pyspark.sql.functions import round, col

emp_tgt1 = emp_tgt1.select(
    round("EMPNO",0).alias("EMPNO_TGT"),
    emp_tgt1["ENAME"].alias("ENAME_TGT"),
    round("DEPTNO", 0).alias("DEPTNO_TGT"),
    round("SAL",2).alias("SAL_TGT"),
    round("COMM",2).alias("COMM_TGT")
    )

# perform left join on 
emp_scd1 = emp_src1.join(emp_tgt1, emp_src1.EMPNO == emp_tgt1.EMPNO_TGT, how = "left")
emp_scd1.show()

# COMMAND ----------

# Insert Flag

scd1_df = emp_scd1.withColumn(
    "INS_FLAG", 
    f.when( (emp_scd1.EMPNO != emp_scd1.EMPNO_TGT) | emp_scd1.EMPNO_TGT.isNull(), "Y") \
    .otherwise("NA")
    )

# Update Flag

scd2_df = scd1_df.withColumn('UPD_FLAG', 
    f.when( (scd1_df.EMPNO == scd1_df.EMPNO_TGT) & (scd1_df.SAL != scd1_df.SAL_TGT),'Y') \
    .otherwise('NA')
    )
    
scd2_df.show()

# COMMAND ----------

# Insert else Update Operation

# insert records df

scd_ins = scd2_df.select(
    'EMPNO', 'ENAME', 'DEPTNO', 'SAL', 'COMM'
    ) \
    .filter(scd2_df.INS_FLAG == 'Y')
    
display(scd_ins.limit(5))

# COMMAND ----------

# Update records df
scd_upd = scd2_df.select('EMPNO', 'ENAME', 'DEPTNO', 'SAL', 'COMM').filter(scd2_df.UPD_FLAG == 'Y')
scd_upd.show(5)

# COMMAND ----------

# records to be overridden
scd_over = scd2_df.select(
    'EMPNO', 'ENAME', 'DEPTNO', 'SAL', 'COMM'
).filter(
    (scd2_df.UPD_FLAG != 'Y') & (scd2_df.INS_FLAG != 'Y')
)

# COMMAND ----------

# Perform Union on Data Frames and insert records into table:

df_final = scd_ins.unionAll(scd_upd).unionAll(scd_over)
df_final.show()
df_final.count()

# COMMAND ----------

df_final.write \
    .format("sqlserver") \
    .mode("overwrite") \
    .options(**properties) \
    .option("dbtable", "emp_spark_scd1") \
    .save()

# COMMAND ----------

# MAGIC %sql
# MAGIC use adls.tulasi

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE employee (
# MAGIC     employee_id INT PRIMARY KEY,
# MAGIC     first_name VARCHAR(50),
# MAGIC     last_name VARCHAR(50),
# MAGIC     email VARCHAR(100),
# MAGIC     create_update_date DATE
# MAGIC );
# MAGIC
# MAGIC INSERT INTO employee (employee_id, first_name, last_name, email, create_update_date)
# MAGIC VALUES
# MAGIC     (100, 'Steven', 'King', 'steven.king@contoso.com', '2023-01-27'),
# MAGIC     (101, 'Neena', 'Kochhar', 'neena.kocchar@contoso.com', '2023-02-09'),
# MAGIC     (102, 'Lex', 'De Haan', 'lex.de-haan@contoso.com', '2023-04-07'),
# MAGIC     (103, 'Alexander', 'Hunold', 'alexander.hunold@contoso.com', '2023-02-24'),
# MAGIC     (104, 'Bruce', 'Ernst', 'bruce.ernst@contoso.com', '2023-04-24');
# MAGIC
# MAGIC CREATE TABLE employee_addresse (
# MAGIC     employee_id INT PRIMARY KEY,
# MAGIC     city VARCHAR(100),
# MAGIC     region VARCHAR(100),
# MAGIC     street_address VARCHAR(255),
# MAGIC     country VARCHAR(100),
# MAGIC     create_update_date DATE
# MAGIC );
# MAGIC
# MAGIC INSERT INTO employee_addresse (employee_id, city, region, street_address, country, create_update_date)
# MAGIC VALUES
# MAGIC     (100, 'New York', 'NY', '123 Main St', 'United States', '2023-01-27'),
# MAGIC     (101, 'London', 'England', '456 Park Ave', 'United Kingdom', '2023-02-09'),
# MAGIC     (102, 'Paris', 'île-de-France', '789 Rue de la Paix', 'France', '2023-04-07'),
# MAGIC     (103, 'Tokyo', 'Tokyo', '1-2-3 Shibuya', 'Japan', '2023-02-24'),
# MAGIC     (104, 'Sydney', 'NSW', '456 George St', 'Australia', '2023-04-24');
# MAGIC
# MAGIC CREATE TABLE employee_details (
# MAGIC     employee_id INT PRIMARY KEY,
# MAGIC     salary DECIMAL(10, 2),
# MAGIC     is_fte BOOLEAN,
# MAGIC     is_remote BOOLEAN,
# MAGIC     employment_date DATE,
# MAGIC     create_update_date DATE
# MAGIC );
# MAGIC
# MAGIC INSERT INTO employee_details (employee_id, salary, is_fte, is_remote, employment_date, create_update_date)
# MAGIC VALUES
# MAGIC     (100, 5000, TRUE, FALSE, '2020-01-15', '2023-01-27'),
# MAGIC     (102, 5500, TRUE, FALSE, '2021-03-22', '2023-04-07'),
# MAGIC     (101, 6000, TRUE, TRUE, '2019-05-10', '2023-02-09'),
# MAGIC     (103, 5200, TRUE, TRUE, '2018-11-30', '2023-02-24'),
# MAGIC     (104, 5800, TRUE, FALSE, '2017-09-12', '2023-04-24');
# MAGIC
# MAGIC

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType
from datetime import datetime
import pyspark.sql.functions as F

data_employee = [
    ("1XYZ", datetime.strptime("2025-01-01", "%Y-%m-%d").date(), "New York", "HR"),
    ("2 ABC", datetime.strptime("2024-12-15", "%Y-%m-%d").date(), "San Francisco", "Finance"),
    ("3 YUI", datetime.strptime("2024-12-20", "%Y-%m-%d").date(), "Boston", "IT"),
    ("4XYZ", datetime.strptime("2025-02-10", "%Y-%m-%d").date(), "Chicago", "HR")
]

schema_employee = StructType([
    StructField("EMPID", StringType(), True),
    StructField("START_DATE", DateType(), True),
    StructField("LOC", StringType(), True),
    StructField("DEPT", StringType(), True)
])

df_source = spark.createDataFrame(data_employee, schema_employee)

data_dim_employee = [
    ("1XYZ", datetime.strptime("2025-01-01", "%Y-%m-%d").date(), "New York", "HR", None, None, 1),
    ("2 ABC", datetime.strptime("2024-12-15", "%Y-%m-%d").date(), "San Francisco", "Finance", None, None, 1),
    ("3 YUI", datetime.strptime("2024-12-20", "%Y-%m-%d").date(), "Boston", "IT", None, None, 1)
]

schema_dim_employee = StructType([
    StructField("EMPID", StringType(), True),
    StructField("START_DATE", DateType(), True),
    StructField("LOC", StringType(), True),
    StructField("DEPT", StringType(), True),
    StructField("UPDATE_DATE", DateType(), True),
    StructField("END_DATE", DateType(), True),
    StructField("CURRENT_FLAG", IntegerType(), True)
])

df_target = spark.createDataFrame(data_dim_employee, schema_dim_employee)

df_combined = df_source.alias("source").join(
    df_target.alias("target"), 
    on="EMPID", 
    how="left_outer"
)

df_combined = df_combined.withColumn(
    "is_updated",
    F.when(
        (F.col("source.LOC") != F.col("target.LOC")) | (F.col("source.DEPT") != F.col("target.DEPT")),
        F.lit(True)
    ).otherwise(F.lit(False))
)

df_target_updated = df_combined.filter(F.col("is_updated") == True).withColumn(
    "END_DATE", F.current_date()
).withColumn(
    "CURRENT_FLAG", F.lit(0)
)

df_source_new = df_combined.filter(F.col("is_updated") == False).withColumn(
    "START_DATE", F.current_date()
).withColumn(
    "END_DATE", F.lit(None).cast(DateType())
).withColumn(
    "CURRENT_FLAG", F.lit(1)
)

df_final = df_target_updated.union(df_source_new)

display(df_final)
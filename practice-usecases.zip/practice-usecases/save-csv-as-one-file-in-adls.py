# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE EmployeeHistory (
# MAGIC     ID INT,
# MAGIC     VERSION INT,
# MAGIC     NAME VARCHAR(100),
# MAGIC     POSITION VARCHAR(100),
# MAGIC     PAY INT,
# MAGIC     COMMENT VARCHAR(255)
# MAGIC );
# MAGIC
# MAGIC INSERT INTO EmployeeHistory (ID, VERSION, NAME, POSITION, PAY, COMMENT) VALUES
# MAGIC (1, 1, 'John Doe', 'Owner', 100, 'Started company'),
# MAGIC (1, 2, 'John Doe', 'Owner', 80, 'Pay cut to hire a coder'),
# MAGIC (2, 1, 'Mark May', 'Coder', 20, 'Hire said coder'),
# MAGIC (2, 2, 'Mark May', 'Coder', 30, 'Productive coder gets raise'),
# MAGIC (3, 1, 'Jane Field', 'Admn Asst', 15, 'Need office staff'),
# MAGIC (2, 3, 'Mark May', 'Coder', 35, 'Productive coder gets raise'),
# MAGIC (1, 3, 'John Doe', 'Owner', 120, 'Sales = profit for owner!'),
# MAGIC (3, 2, 'Jane Field', 'Admn Asst', 20, 'Raise for office staff'),
# MAGIC (4, 1, 'Cody Munn', 'Coder', 20, 'Hire another coder'),
# MAGIC (4, 2, 'Cody Munn', 'Coder', 25, 'Give that coder raise'),
# MAGIC (3, 3, 'Jane Munn', 'Admn Asst', 20, 'Jane marries Cody <3'),
# MAGIC (2, 4, 'Mark May', 'Dev Lead', 40, 'Promote mark to Dev Lead'),
# MAGIC (4, 3, 'Cody Munn', 'Coder', 30, 'Give Cody a raise'),
# MAGIC (2, 5, 'Mark May', 'Retired', 0, 'Mark retires'),
# MAGIC (5, 1, 'Joey Trib', 'Dev Lead', 40, 'Bring outside help for Dev Lead'),
# MAGIC (6, 1, 'Hire Meplz', 'Coder', 10, 'Hire a cheap coder'),
# MAGIC (3, 4, 'Jane Munn', 'Retired', 0, 'Jane quits'),
# MAGIC (7, 1, 'Work Fofre', 'Admn Asst', 10, 'Hire Janes replacement'),
# MAGIC (8, 1, 'Fran Hesky', 'Coder', 10, 'Hire another coder'),
# MAGIC (9, 1, 'Deby Olav', 'Coder', 25, 'Hire another coder'),
# MAGIC (4, 4, 'Cody Munn', 'VP Ops', 80, 'Promote Cody'),
# MAGIC (9, 2, 'Deby Olav', 'VP Ops', 80, 'Cody fails at VP Ops, promote Deby'),
# MAGIC (4, 5, 'Cody Munn', 'Retired', 0, 'Cody retires in shame'),
# MAGIC (5, 2, 'Joey Trib', 'Dev Lead', 50, 'Give Joey a raise');

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from EmployeeHistory

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into EmployeeHistory
# MAGIC values (10, 6, 'Mira Curt', 'Intern', 5 , 'Underpaid, as you can tell')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from employeehistory

# COMMAND ----------

df = spark.sql("SELECT * FROM employeehistory")

# COMMAND ----------

df.display()

# COMMAND ----------

file_name = 'employeehistory.csv'
file_path = 'abfss://container@storageaccount.dfs.core.windows.net/gourinandan/'

# COMMAND ----------

def write_to_csv_with_name(df, file_name, file_path, header=True):
    if file_path is None or file_name is None:
        raise ValueError("file_path and file_name must be provided")

    df.coalesce(1).write.mode("overwrite").format("csv").option("header", "True").save(file_path + "temp")
    fname = [filename.name for filename in dbutils.fs.ls(file_path + "temp") if filename.name.endswith('.csv')]
    dbutils.fs.mv(file_path + "temp/" + fname[0], file_path + file_name)
    dbutils.fs.rm(file_path + "temp", True)

write_to_csv_with_name(df, file_name, file_path, header=True)

# COMMAND ----------

df.write.format("csv")
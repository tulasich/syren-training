# Databricks notebook source
# MAGIC %md
# MAGIC     Day 1(20th-jan):-
# MAGIC
# MAGIC     explore on file formats (parquet,delta)
# MAGIC             difference between them 
# MAGIC             advantage of these file formats 
# MAGIC             append vs overwrite mode
# MAGIC             explore on partitoning and bucketing 
# MAGIC
# MAGIC     steps :
# MAGIC       1. read csv file
# MAGIC       2. perform some pyspark transformations 
# MAGIC       3. save as table (1.parquet,2.delta) 
# MAGIC       4. while writing data to destination use partitioning (with delta table) and bucketing(for parquet only table) and check difference

# COMMAND ----------

# MAGIC %md
# MAGIC ###### question - can't write to adls as csv from dataframe? Answer - it's working but is storing in delta format - ensuring acid properties

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DateType, TimestampType, DoubleType, FloatType

# COMMAND ----------

# MAGIC %fs ls "abfss://container@storageaccount.dfs.core.windows.net/tulasi/"

# COMMAND ----------

# read csv file

df = spark.read \
        .format("csv") \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .load("abfss://container@storageaccount.dfs.core.windows.net/vamshi/customers.csv")

df.display()

# COMMAND ----------

df.inputFiles()

# COMMAND ----------

df.select(df["Index"].name("notindex")).display()
notdf = df.alias("notdf")
notdf.display()

# COMMAND ----------

# perform some pyspark transformations

df = df.withColumn(
    "fullname", 
    F.concat(F.col("First Name"), F.lit(" "), F.col("Last Name"))
)

df = df.withColumn(
    "Cleaned_PNo1", 
    F.regexp_replace(
        F.col("Phone1"), 
        r"[^0-9x]+|x.*",
        ""
    )
)

df = df.withColumn(
    "Cleaned_PNo2", 
    F.regexp_replace(
        F.col("Phone2"), 
        r"[^0-9x]+|x.*",
        ""
    )
)

df = df.withColumn("Country", F.trim(df.Country))

display(df)

# COMMAND ----------

# save as table (1.parquet,2.delta) 

# while writing data to destination use partitioning (with delta table) and bucketing(for parquet only table) and check difference

# modes overwrite vs mode append vs mode ignore vs mode error
# overwrites existing data - appends to the existing data - ignores the write operation if file already exists - throws error if file exists

# bucketBy

# bucketBy(numBuckets, col)

# 1.parquet

df.write \
    .format("parquet") \
    .mode("overwrite") \
    .bucketBy(5, "Country") \
    .option("path", "abfss://container@storageaccount.dfs.core.windows.net/tulasi/customers_parquet") \
    .saveAsTable("adls.tulasi.customer_parquet")

# COMMAND ----------

# 2. delta

# partitionBy

# partitionBy(col)

df.write \
    .format("delta") \
    .mode("overwrite") \
    .partitionBy("Country") \
    .option("path", "abfss://container@storageaccount.dfs.core.windows.net/tulasi/customers_delta") \
    .option("delta.columnMapping.mode", "name") \
    .saveAsTable("adls.tulasi.customer_delta")

# COMMAND ----------

df.write \
    .format("delta") \
    .mode("append") \
    .partitionBy("Country") \
    .option("path", "abfss://container@storageaccount.dfs.core.windows.net/tulasi/customers_delta_append") \
    .option("delta.columnMapping.mode", "name") \
    .saveAsTable("adls.tulasi.customer_append_delta")

# COMMAND ----------

append_df = spark.read.table("adls.tulasi.customer_append_delta")
append_df.display()

# COMMAND ----------

df.display()

# COMMAND ----------

df.select("Country").distinct().display()

# COMMAND ----------

qol_df = spark.read \
  .format("csv") \
  .option("header", "true") \
  .load("abfss://container@storageaccount.dfs.core.windows.net/anusha/Quality_of_Life.csv")

qol_df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("path", "abfss://container@storageaccount.dfs.core.windows.net/tulasi/quality_of_life_delta") \
    .saveAsTable("adls.tulasi.quality_of_life_delta")

# COMMAND ----------

for col in qol_df.columns:
    qol_df = qol_df.withColumnRenamed(col, col.replace(" ", "_"))

display(qol_df)

# COMMAND ----------

for col in qol_df.columns:
    print(col)

qol_df.printSchema()

# COMMAND ----------


# Create Sample data
# Imports
import pyspark
from pyspark.sql import SparkSession
spark=SparkSession.builder.appName("parquetFile").getOrCreate()
data =[("James ","","Smith","36636","M",3000),
              ("Michael ","Rose","","40288","M",4000),
              ("Robert ","","Williams","42114","M",4000),
              ("Maria ","Anne","Jones","39192","F",4000),
              ("Jen","Mary","Brown","","F",-1)]
columns=["firstname","middlename","lastname","dob","gender","salary"]
df=spark.createDataFrame(data,columns)

# COMMAND ----------

df.write.parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/someparquetfile")

# COMMAND ----------

df.write.mode("append").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/someparquetfile")

# COMMAND ----------

spark.read.parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/someparquetfile").display()

# COMMAND ----------

df.write.mode("overwrite").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/someparquetfile")

# COMMAND ----------

df.write.mode("ignore").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/someparquetfile")

# COMMAND ----------

df.write.mode("error").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/someparquetfile")

# COMMAND ----------

df.write.partitionBy("gender","salary").mode("overwrite").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/someparquetfile")

# COMMAND ----------

spark.read.parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/someparquetfile/gender=M").display()

# COMMAND ----------

df.write.format("delta").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/somedeltafile")

# COMMAND ----------

df.write.partitionBy("gender", "salary") \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/somedeltafile")

# COMMAND ----------

df.write.bucketBy(3,"gender").mode("overwrite").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/somenewfile")
# Databricks notebook source
# MAGIC %md
# MAGIC #### Scenario: Employee Pay Tracker & Report Generator
# MAGIC In this scenario, we are managing employee data and tracking pay changes. The table contains a history of pay changes, with columns for Employee ID, Version, Position, Pay, and Comments. We want to implement a system that:
# MAGIC
# MAGIC - Tracks pay changes over time for each employee.
# MAGIC Identifies employees who have had significant pay raises or cuts (e.g., raises above 20% or cuts below 10%).
# MAGIC - Generates reports of employees with significant changes and stores the results in a data lake or another database.
# MAGIC - Notifies HR or Management via an email or a log if any employees have experienced significant changes.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Pay Change Analysis
# MAGIC `This notebook will Calculate the percentage change in pay for each employee.`
# MAGIC
# MAGIC `Return a list of employees who have experienced a significant pay raise or cut.`

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

df = spark.sql("select * from employeehistory")

# COMMAND ----------

windowspec = Window.partitionBy("ID").orderBy("VERSION")

# percentage change in pay for each employee
df = df.withColumn(
    "PCT_CHANGE",
    F.round(
        (
            F.try_divide(
                (df["pay"] - F.lag(df["pay"]).over(windowspec)),
                F.lag(df["pay"]).over(windowspec),
            )
            * 100
        ),
        2,
    ),
)

display(df)

significant_change = df.filter(
    (df["PCT_CHANGE"] > 20) | (df["PCT_CHANGE"] < -10)
)

display(significant_change)

# Return a list of employees who have experienced a significant pay raise or cut
result = []

for row in significant_change.collect():
    result.append({
        "Employee ID": row["ID"],
        "Name": row["NAME"],
        "Pay": row["PAY"],
        "Pay Change (%)": row["PCT_CHANGE"],
        "Comment": row["COMMENT"]
    })

print(result)

dbutils.notebook.exit(result)

# COMMAND ----------

significant_change.write \
    .format("sqlserver") \
    .mode("overwrite") \
    .option("host", "azdb.database.windows.net") \
    .option("user", dbutils.secrets.get(scope="siva_scope", key = 'username')) \
    .option("password", dbutils.secrets.get(scope="siva_scope", key = 'password')) \
    .option("database", "db") \
    .option("dbtable", "dbo.significant_change") \
    .save()

# COMMAND ----------

# DBTITLE 1,writing to sqlserver using siva secret scope
df.write \
    .format("sqlserver") \
    .mode("overwrite") \
    .option("host", "az-sqlserver.database.windows.net") \
    .option("user", dbutils.secrets.get(scope="siva_scope", key = 'username')) \
    .option("password", dbutils.secrets.get(scope="siva_scope", key = 'password')) \
    .option("database", "db") \
    .option("dbtable", "dbo.employeehistory") \
    .save()

# COMMAND ----------

df.explain()
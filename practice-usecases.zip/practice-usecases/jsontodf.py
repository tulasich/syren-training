# Databricks notebook source
from pyspark.sql import functions as F

# COMMAND ----------

import json
import requests

headers = {
    'Content-Type': 'application/json',
  	'QB-Realm-Hostname': 'host.quickbase.com',
	'User-Agent': '{User-Agent}',
	'Authorization': 'QB-USER-TOKEN token'
}
body = {"from":"table2"} #table2 table1
r = requests.post(
'https://api.quickbase.com/v1/records/query', 
headers = headers, 
json = body
)

x = json.dumps(r.json(),indent=4)

# COMMAND ----------

import json
import requests

headers = {
    'Content-Type': 'undefined',
  	'QB-Realm-Hostname': 'host.quickbase.com',
	'User-Agent': '{User-Agent}',
	'Authorization': 'QB-USER-TOKEN token'
}
body = {"from":"table1"}
r = requests.post(
'https://api.quickbase.com/v1/records/query', 
headers = headers, 
data = body
)

# COMMAND ----------

d = r.json()
data = d["data"]
fields = d["fields"]

schema_fields = []
for field in fields:
    if field['type'] == "numeric":
        schema_fields.append(StructField(field['label'], FloatType(), True))
    elif field['type'] : # like "text"
        schema_fields.append(StructField(field['label'], StringType(), True))

schema = StructType(schema_fields)

print(schema)

processed_data = []
for record in data:
    row = []
    for field in fields:
        field_id = str(field['id'])  
        if field_id in record:
            row.append(record[field_id]['value'])
        else:
            row.append(None)  
    processed_data.append(row)

data_df = spark.createDataFrame(processed_data, schema)

data_df.display()

# COMMAND ----------

print(x)

# COMMAND ----------

# {"data": [ {"10": {"value": "Yes"},"11": {"value": "Yes"},"12": {"value": "Supplier Audits"},"13": {"value": "Audit performance (SI, CAI, EAI)"},"14": {"value": "Core Business"},"15": {"value": 5.0},"16": {"value": "Yearly Assessments"},"17": {"value": "What is the supplier's audit outcome rating?"},"3": {"value": 1},"6": {"value": "Cat1_Hz1"},"7": {"value": "A, B, C, D, E, F, G, H, I, J"},"8": {"value": "Yes"},"9": {"value": "Yes"}} ]

# "fields": [{"id": 3,"label": "Record ID#","type": "recordid"},{"id": 6,"label": "Hazard Record ID","type": "text-multiple-choice"},{"id": 7,"label": "in_Supplier_Type","type": "text"},{"id": 8,"label": "in_Supplier_CL1","type": "text"},{"id": 9,"label": "in_Supplier_CL2","type": "text"},{"id": 10,"label": "in_Supplier_CL3","type": "text"},{"id": 11,"label": "in_Supplier_CL4","type": "text"},{"id": 12,"label": "in_Hazard_Category","type": "text"},{"id": 13,"label": "in_Parameter","type": "text"},{"id": 14,"label": "in_Strategic_Importance","type": "text"},{"id": 15,"label": "disp_Startegic_Weight","type": "numeric"},{"id": 16,"label": "in_Assessment_Frequency","type": "text"},{"id": 17,"label": "in_Hazards","type": "text"} ]}

# COMMAND ----------

# MAGIC %md
# MAGIC d = r.json()
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as F

d = r.json()
df = spark.createDataFrame([d])
display(df)

df1 = df.select(
    F.explode("data").alias("id"),
)

display(df1)

df2 = df1.select(
    F.explode("id").alias("id", "value"),
)

display(df2)

df3 = df2.select(
    "id",
    F.explode("value").alias("id", "value"),
)

df3.display()

# COMMAND ----------

df.select(
    "data","fields", "metadata").show()

# COMMAND ----------

fields_df = df.select("fields")
display(fields_df)

fields_op_df = fields_df.select(F.explode("fields").alias("fields"))

fields_op_df = fields_op_df.select(
    F.col("fields.id").alias("id"),
    F.col("fields.label").alias("label"),
    F.col("fields.type").alias("type")
)
display(fields_op_df)

# COMMAND ----------

metadata_df = df.select("metadata")

metadata_df = metadata_df.select(
    F.explode("metadata").alias("key", "value")
)

metadata_df.display()

# COMMAND ----------

d = r.json()
data = d["data"]
print(data)

data_df = data_df.select("data")
data_df.display()

# COMMAND ----------

for field in d["fields"]:
    print(field["label"] + " " + field["type"])

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, NumericType, IntegerType, ArrayType, FloatType

schema = StructType([
    StructField("Record ID#", IntegerType(), True),
    StructField("Hazard Record ID", ArrayType(StringType()), True),
    StructField("in_Supplier_Type", StringType(), True),
    StructField("in_Supplier_CL1", StringType(), True),
    StructField("in_Supplier_CL2", StringType(), True),
    StructField("in_Supplier_CL3", StringType(), True),
    StructField("in_Supplier_CL4", StringType(), True),
    StructField("in_Hazard_Category", StringType(), True),
    StructField("in_Parameter", StringType(), True),
    StructField("in_Strategic_Importance", StringType(), True),
    StructField("disp_Startegic_Weight", StringType(), True),
    StructField("in_Assessment_Frequency", StringType(), True),
    StructField("in_Hazards", StringType(), True),
])

# COMMAND ----------

# method 1 - fail - absolutely

# COMMAND ----------

data_df = spark.createDataFrame([d])

# COMMAND ----------

data_df.select(
    data_df["data"][0],
    data_df["data"][1]
).display()

# COMMAND ----------

rows = []
current_row = []

for record in d["data"]:
    for key, subdict in record.items():
        current_row.append(subdict["value"])
        
    if len(current_row) == 13:
        rows.append(current_row)
        current_row = []

if current_row:
    rows.append(current_row)

for row in rows:
    print(row)



# COMMAND ----------

final_df = spark.createDataFrame(rows, schema)

# COMMAND ----------

final_df.select().display()

# COMMAND ----------

print(rows)

# COMMAND ----------

final_df = spark.createDataFrame(rows, schema)
final_df.display()

# COMMAND ----------

flattened_data = []

for record in d["data"]:
    flattened_record = {key: subdict['value'] for key, subdict in record.items()}
    flattened_data.append(flattened_record)

print(flattened_data)

# COMMAND ----------

# MAGIC %md
# MAGIC ------------------------------------------------

# COMMAND ----------

print(data[0])

# COMMAND ----------

# MAGIC %md
# MAGIC [{ 'key' : {}, 'key' : {}, 'key' : {}, ....}, { 'key' : {}, 'key' : {}, 'key' : {}, ....}, { 'key' : {}, 'key' : {}, 'key' : {}, ....}, { 'key' : {}, 'key' : {}, 'key' : {}, ....}, { {}, {}, {}, ....}, { {}, {}, {}, ....}, ...]

# COMMAND ----------

# # print(data[0]['7'])

# # Iterate through each dictionary in the list
# for record in data:
#     # Create a list of keys to avoid modifying the dictionary while iterating
#     for key in list(record.keys()):
#         # Convert the key to an integer
#         int_key = int(key)
        
#         # Replace the old key with the new integer key, preserving the value
#         record[int_key] = record.pop(key)

# print(data)

# COMMAND ----------

print(data[0]['10']['value'])

# COMMAND ----------

print(x)

# COMMAND ----------

d = r.json()
data = d["data"]
fields = d["fields"]

# COMMAND ----------

for field in fields:
    print(field)

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, FloatType

# COMMAND ----------

schema_fields = []
for field in fields:
    if field['type'] == "numeric":
        schema_fields.append(StructField(field['label'], FloatType(), True))
    elif field['type'] : # like "text"
        schema_fields.append(StructField(field['label'], StringType(), True))

schema = StructType(schema_fields)

print(schema)

processed_data = []
for record in data:
    row = []
    for field in fields:
        field_id = str(field['id'])  
        if field_id in record:
            row.append(record[field_id]['value'])
        else:
            row.append(None)  
    processed_data.append(row)

data_df = spark.createDataFrame(processed_data, schema)

data_df.display()

# COMMAND ----------



# COMMAND ----------

print(processed_data)

# COMMAND ----------

# we extract values from every row of the json file with indexing it as data[index]['id']['value']
# this way, we can access the values of the json file with the id as the key
# now, we map it with the values of the "fields" - which is our schema
# and then creating a dataframe

# COMMAND ----------

import json
import requests
from pyspark.sql.types import StructType, IntegerType, StructField, StringType, DoubleType, DateType, TimestampType, BooleanType
from datetime import datetime

class QuickbaseAPI:
    def json_def(self, tableid):
        headers = {
            'Content-Type': 'application/json',
            'QB-Realm-Hostname': 'janssenvcm.quickbase.com',
            'User-Agent': '{User-Agent}',
            'Authorization': 'QB-USER-TOKEN token'
        }
        body = {"from": tableid}
        r = requests.post(
            'https://api.quickbase.com/v1/records/query', 
            headers=headers, 
            json=body
        )
        return r.json()

    def data_transform(self, data, fields):
        processed_data = []
        for record in data:
            row = []
            for field in fields:
                field_id = str(field['id'])  
                if field_id in record:
                    row.append(record[field_id]['value'])
                else:
                    row.append(None)  
            processed_data.append(row)

        return processed_data
        

    def datatype_schema(self, data, fields):
        
        schema_fields = []

        field_type_mapping = {
            "numeric": DoubleType(),
            "text": StringType(),
            "text-multiple-choice": StringType(),
            "rich-text": StringType(),
            "date": DateType(),
            "datetime": TimestampType(),
            "checkbox": BooleanType(),
        }
        
        # Create schema fields based on field types
        for field in fields:
            field_type = field_type_mapping.get(field['type'], StringType())
            schema_fields.append(StructField(field['label'], field_type, True))

        schema = StructType(schema_fields)

        return schema


    def create_dataframe(self, processed_data, schema):

        data_df = spark.createDataFrame(processed_data, schema)

        display(data_df)
        data_df.printSchema()

        return data_df

qb = QuickbaseAPI()

json_data = qb.json_def("table1")

data = json_data["data"]
fields = json_data["fields"]

processed_data = qb.data_transform(data, fields)
schema = qb.datatype_schema(data, fields)
qb.create_dataframe(processed_data, schema)

# COMMAND ----------



# COMMAND ----------

import json
import requests
from pyspark.sql.types import (
    StructType, IntegerType, StructField, StringType, 
    DoubleType, DateType, TimestampType, BooleanType
)

from datetime import datetime

class QuickbaseAPI:
    def __init__(self, spark):
        self.spark = spark

    def json_def(self, tableid):
        headers = {
            'Content-Type': 'application/json',
            'QB-Realm-Hostname': 'host.quickbase.com',
            'User-Agent': '{User-Agent}',
            'Authorization': 'QB-USER-TOKEN token'
        }

        body = {"from": tableid}
        r = requests.post(
            'https://api.quickbase.com/v1/records/query', 
            headers=headers, 
            json=body
        )

        return r.json()


    # transforms the json data into a list of lists and handles the data types of rows being appended

    def data_transform(self, data, fields):
        processed_data = []
        
        for record in data:
            row = []
            
            for field in fields:
                field_id = str(field['id'])
                value = None
                
                if field_id in record and 'value' in record[field_id]:
                    value = record[field_id]['value']
                    
                    # Handle type conversion here
                    if field['type'] == "numeric" and value is not None:
                        try:
                            value = float(value)  # Convert numeric values to float
                        except ValueError:
                            value = None  # If conversion fails, set to None
                    elif field['type'] == "recordid" and value is not None:
                        try:
                            value = int(value)  # Convert recordid to int
                        except ValueError:
                            value = None  # If conversion fails, set to None
                    elif field['type'] == "checkbox" and value is not None:
                        if isinstance(value, str):  # If it's a string, convert to boolean
                            value = value.lower() == "true"
                        elif isinstance(value, bool):  # If it's already a boolean, leave it as is
                            pass
                        else:
                            value = None  # If it's neither, set to None
                    elif field['type'] == "timestamp" and value is not None:
                        try:
                            # Convert string timestamp to datetime object
                            value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%fZ")  # Adjust format if needed
                        except ValueError:
                            value = None  # If conversion fails, set to None
                    elif field['type'] == "date" and value is not None:
                        try:
                            value = datetime.strptime(value, "%Y-%m-%d").date()  # Adjust date format if needed
                        except ValueError:
                            value = None  # If conversion fails, set to None

                row.append(value)
            
            processed_data.append(row)

        return processed_data

        
    # generates schema depending on the type of columns 

    def datatype_schema(self, data, fields):
            
        schema_fields = []

        for field in fields:
            if field['type'] == "recordid":
                schema_fields.append(StructField(field['label'], IntegerType(), True))
            elif field['type'] == "numeric":
                schema_fields.append(StructField(field['label'], DoubleType(), True))
            elif field['type'] in ["text", "text-multi-line", "rich-text"]:
                schema_fields.append(StructField(field['label'], StringType(), True))
            elif field['type'] == "date":
                schema_fields.append(StructField(field['label'], DateType(), True))
            elif field['type'] == "timestamp":
                schema_fields.append(StructField(field['label'], TimestampType(), True))
            elif field['type'] == "checkbox":
                schema_fields.append(StructField(field['label'], BooleanType(), True))
            else:
                schema_fields.append(StructField(field['label'], StringType(), True))

        schema = StructType(schema_fields)
        print(f"Schema created: {schema}")
        return schema



    def start(self):
        table_id = "table1"

        json_data = self.json_def(table_id) #table2 table1

        data = json_data["data"]

        fields = json_data["fields"]

        processed_data = self.data_transform(data, fields)

        schema = self.datatype_schema(data, fields)

        data_df = self.spark.createDataFrame(processed_data, schema)

        display(data_df)
        data_df.printSchema()

        return data_df

# Pass the Spark session to the QuickbaseAPI class
qb = QuickbaseAPI(spark)
data_df = qb.start()

# COMMAND ----------

import json
import requests
from pyspark.sql.types import (
    StructType, IntegerType, StructField, StringType, 
    DoubleType, DateType, TimestampType, BooleanType
)

from datetime import datetime

class QuickbaseAPI:
    def __init__(self, spark):
        self.spark = spark

    def json_def(self, tableid):
        headers = {
            'Content-Type': 'application/json',
            'QB-Realm-Hostname': 'host.quickbase.com',
            'User-Agent': '{User-Agent}',
            'Authorization': 'QB-USER-TOKEN token'
        }
        body = {"from": tableid}
        r = requests.post(
            'https://api.quickbase.com/v1/records/query', 
            headers=headers, 
            json=body
        )
        return r.json()


    def data_transform(self, data, fields):
        processed_data = []

        # Create a mapping of field labels to their index in the schema
        field_labels = [field['label'] for field in fields]
        
        for record in data:
            row = [None] * len(fields)  # Initialize a row with None for each field
            
            for field in fields:
                field_id = str(field['id'])
                value = None

                # Check if the field exists in the record and has a value
                if field_id in record and 'value' in record[field_id]:
                    value = record[field_id]['value']
                    
                    # Handle type conversion based on field type
                    if field['type'] == "numeric" and value is not None:
                        try:
                            value = float(value)
                        except ValueError:
                            value = None
                    
                    elif field['type'] == "recordid" and value is not None:
                        try:
                            value = int(value)
                        except ValueError:
                            value = None
                    
                    elif field['type'] == "checkbox" and value is not None:
                        if isinstance(value, str):
                            value = value.lower() == "true"
                        elif isinstance(value, bool):
                            pass
                        else:
                            value = None
                    
                    elif field['type'] == "timestamp" and value is not None:
                        try:
                            value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%fZ")
                        except ValueError:
                            value = None
                    
                    elif field['type'] == "date" and value is not None:
                        try:
                            value = datetime.strptime(value, "%Y-%m-%d").date()
                        except ValueError:
                            value = None
                
                # If value is valid, assign it to the correct index in the row
                if value is not None:
                    field_index = field_labels.index(field['label'])  # Get index based on field label
                    row[field_index] = value
            
            # Only append the row if it contains valid data
            if any(val is not None for val in row):
                processed_data.append(row)

        return processed_data
        

    def datatype_schema(self, data, fields):
            
        schema_fields = []

        for field in fields:
            if field['type'] == "recordid":
                schema_fields.append(StructField(field['label'], IntegerType(), True))
            elif field['type'] == "numeric":
                schema_fields.append(StructField(field['label'], DoubleType(), True))
            elif field['type'] in ["text", "text-multi-line", "rich-text"]:
                schema_fields.append(StructField(field['label'], StringType(), True))
            elif field['type'] == "date":
                schema_fields.append(StructField(field['label'], DateType(), True))
            elif field['type'] == "timestamp":
                schema_fields.append(StructField(field['label'], TimestampType(), True))
            elif field['type'] == "checkbox":
                schema_fields.append(StructField(field['label'], BooleanType(), True))
            else:
                schema_fields.append(StructField(field['label'], StringType(), True))

        schema = StructType(schema_fields)
        print(f"Schema created: {schema}")
        return schema


    def start(self):
        table_id = "table1"

        json_data = self.json_def(table_id) #table2 table1

        data = json_data["data"]

        fields = json_data["fields"]

        processed_data = self.data_transform(data, fields)

        schema = self.datatype_schema(data, fields)

        data_df = self.spark.createDataFrame(processed_data, schema)

        display(data_df)
        data_df.printSchema()

        return data_df

# Pass the Spark session to the QuickbaseAPI class
qb = QuickbaseAPI(spark)
data_df = qb.start()

# COMMAND ----------

import json
import requests

headers = {
    'Content-Type': 'application/json',
  	'QB-Realm-Hostname': 'host.quickbase.com',
	'User-Agent': '{User-Agent}',
	'Authorization': 'QB-USER-TOKEN token'
}
body = {"from":"table1"}
r = requests.post(
'https://api.quickbase.com/v1/records/query', 
headers = headers, 
json = body
)

# COMMAND ----------

d = r.json()

# COMMAND ----------

fields = d["fields"]

# COMMAND ----------

mylist = []
for field in fields:
    mylist.append(field["type"])

unique_elements = []
[unique_elements.append(x) for x in mylist if x not in unique_elements]
print(unique_elements)

# COMMAND ----------

for field in fields:
    print(field["label"])
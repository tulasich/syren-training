# Databricks notebook source
# MAGIC %md
# MAGIC %md
# MAGIC ### Slowly Changing Dimensions
# MAGIC ### **`SCD TYPE 0`**
# MAGIC
# MAGIC SCD Type 0 is a passive approach, if something has changed in the soure dimension, we do not implement that in the warehouse table - retaining the previous values.
# MAGIC
# MAGIC This is implemented when the columns are not relevant anymore, hence avoiding the trouble of changing everything.

# COMMAND ----------

# MAGIC %md
# MAGIC ### **`SCD TYPE 1`**
# MAGIC
# MAGIC Latest snapshot of the data is maintained, if there are any changes in the values, the values will be updated but the history is not tracked.

# COMMAND ----------

# To implement Slowly Changing Dimension (SCD) Type 1 for the provided dataset, we will need to focus on updating the existing records when changes occur. SCD Type 1 overwrites old data with new data when changes are detected (no history is preserved).

# Steps for Implementing SCD Type 1:
# Define your Source and Target tables:

# Source Table: EMP (Contains the incoming data with changes)
# Target Table: EMP_DIM (Contains historical data that will be overwritten if necessary)
# Table structure: We'll assume the structure of both the source and target tables will be similar but with an extra column for tracking updates, such as LAST_UPDATED_DATE.

# COMMAND ----------

# MAGIC %md
# MAGIC ### **`"databricks merge" Into command`**

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- MERGE [ WITH SCHEMA EVOLUTION ] INTO target_table_name [target_alias]
# MAGIC --    USING source_table_reference [source_alias]
# MAGIC --    ON merge_condition
# MAGIC --    { WHEN MATCHED [ AND matched_condition ] THEN matched_action |
# MAGIC --      WHEN NOT MATCHED [BY TARGET] [ AND not_matched_condition ] THEN not_matched_action |
# MAGIC --      WHEN NOT MATCHED BY SOURCE [ AND not_matched_by_source_condition ] THEN not_matched_by_source_action } [...]
# MAGIC
# MAGIC -- matched_action
# MAGIC --  { DELETE |
# MAGIC --    UPDATE SET * |
# MAGIC --    UPDATE SET { column = { expr | DEFAULT } } [, ...] }
# MAGIC
# MAGIC -- not_matched_action
# MAGIC --  { INSERT * |
# MAGIC --    INSERT (column1 [, ...] ) VALUES ( expr | DEFAULT ] [, ...] )
# MAGIC
# MAGIC -- not_matched_by_source_action
# MAGIC --  { DELETE |
# MAGIC --    UPDATE SET { column = { expr | DEFAULT } } [, ...] }
# MAGIC
# MAGIC
# MAGIC -- Step 1: Update existing records if there is a change in data.

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ### **`SCD TYPE 1`**

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql import functions as F

schema = StructType([StructField("emp_id", IntegerType(), True),
                     StructField("name", StringType(), True),
                     StructField("city", StringType(), True),
                     StructField("country", StringType(), True),
                     StructField("contact_no", IntegerType(), True)]
        )

# COMMAND ----------

data = [(1000, "Micheal", "Columbus", "USA", 689546323)]

df = spark.createDataFrame(data, schema)
display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table adls.tulasi.dim_employee(
# MAGIC   emp_id int,
# MAGIC   name string,
# MAGIC   city string,
# MAGIC   country string,
# MAGIC   contact_no int
# MAGIC )
# MAGIC
# MAGIC using delta
# MAGIC location "abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/Spark_SQL/dim_employee"

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from adls.tulasi.dim_employee

# COMMAND ----------

# MAGIC %md
# MAGIC ### Method 1 Spark SQL

# COMMAND ----------

df.createOrReplaceTempView("source_view")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from source_view

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into adls.tulasi.dim_employee as target
# MAGIC using source_view as source
# MAGIC   on target.emp_id = source.emp_id
# MAGIC   when matched then
# MAGIC   update set
# MAGIC     target.name = source.name,
# MAGIC     target.city = source.city,
# MAGIC     target.country = source.country,
# MAGIC     target.contact_no = source.contact_no
# MAGIC   when not matched then
# MAGIC   insert (emp_id, name, city, country, contact_no) values (emp_id, name, city, country, contact_no)

# COMMAND ----------

data = [(1000, "Micheal", "Chicago", "USA", 689546323), (2000, "Nancy", "New York", "USA", 76345902)]

df = spark.createDataFrame(data, schema)

display(df)

# COMMAND ----------

df.createOrReplaceTempView("source_view")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from source_view

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from adls.tulasi.dim_employee

# COMMAND ----------

# run merge again

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from adls.tulasi.dim_employee

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ---------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Delta Tables

# COMMAND ----------

data = [(2000, "Sarah", "New York", "USA", 76345902), (3000, "David", "Atlanta", "USA", 563456787)]

df = spark.createDataFrame(data, schema)
display(df)

df.write.mode("overwrite").format("delta").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/DeltaTableSCD/target/")

# COMMAND ----------

from delta.tables import DeltaTable
delta_df = DeltaTable.forPath(spark, "abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/DeltaTableSCD/target/")

# COMMAND ----------

from pyspark.sql.functions import current_date

delta_df.alias("target").merge(
    df.alias("source"), "source.emp_id = target.emp_id"
).whenMatchedUpdate(
    set={
        "name": "source.name",
        "city": "source.city",
        "country": "source.country",
        "contact_no": "source.contact_no"
    }
).whenNotMatchedInsert(
    values={
        "emp_id": "source.emp_id",
        "name": "source.name",
        "city": "source.city",
        "country": "source.country",
        "contact_no": "source.contact_no"
    }
).execute()

# COMMAND ----------

# SELECT * FROM delta.`abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/DeltaTableSCD/target/`

spark.read.format("delta").load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/DeltaTableSCD/target/").display()

# COMMAND ----------

data = [(2000, "Sarah", "California", "USA", 76345902), (3000, "David", "Atlanta", "USA", 563456787), (4000, "Jose", "Chicago", "USA", 563456787)]

df = spark.createDataFrame(data, schema)
display(df)

# COMMAND ----------

# merge again

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC ---------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using Pyspark

# COMMAND ----------

# Define loadtype to read History Data and Incremental Data

dbutils.widgets.text('loadtype', '')
loadtype = dbutils.widgets.get('loadtype')

# COMMAND ----------

df_source = spark.read.format("csv").option("header", "true").load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/source/cust.csv")

df_source.display()

# COMMAND ----------

# Add a surrogate key to uniquely identify each record for the source data

from pyspark.sql.functions import crc32, concat, current_date, lit

df_source1 = df_source \
    .withColumn("hashkey", crc32(concat(*df_source.columns))) \
    .withColumn("created_date", current_date()) \
    .withColumn("created_by", lit("azuredatabricks")) \
    .withColumn("updated_on", current_date()).withColumn("updated_by", lit("azuredatabricks"))

display(df_source1)

# CRC32 (Cyclic Redundancy Check) is a hash function used to produce a 32-bit checksum (a fixed-size value) from a variable-length input, such as a string or byte sequence. It’s typically used to detect accidental changes or errors in data during transmission or storage, such as file corruption.

# COMMAND ----------

if loadtype == 'History':

   # Write the current Historical Data/Source data to the Target Table

   df_source1.coalesce(1).write.mode("overwrite").option("header", "true").format("csv").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/target/")

   dbutils.notebook.exit("history load success")

# COMMAND ----------

# Read the current Historical Data

df_target = spark.read.format("csv").option("header", "true").load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/target/")

df_target.display()

# COMMAND ----------

# Read the updated data/data of the second day

df_source = spark.read.format("csv").option("header", "true").load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/source/secondday.csv")

display(df_source)

# COMMAND ----------

df_source1 = df_source \
    .withColumn("hashkey", crc32(concat(*df_source.columns))) \
    .withColumn("created_date", current_date()) \
    .withColumn("created_by", lit("azuredatabricks")) \
    .withColumn("updated_on", current_date()).withColumn("updated_by", lit("azuredatabricks"))

display(df_source1)

# COMMAND ----------

# Retrieve data which is only present in the source (secondday.csv) table but not in the historical (target) table when both the id and hashkey are matching

# Meaning new rows which were inserted in the secondday.csv table/

df_upsert = df_source1.join(df_target, 
                (df_source1.hashkey == df_target.hashkey) &
                (df_source1.custid == df_target.custid),
                "leftanti"
            )

display(df_upsert)

# COMMAND ----------

# Extract records from the historical table (df_target) where the customer ID is the same, but the hash key (crc32) differs from the source table (df_source1).

# This isolates records that exist in the historical table but have updates in the source table, based on the hash key mismatch.

df_old = df_target.join(
    df_source1,
    (df_target.hashkey != df_source1.hashkey) & (df_target.custid == df_source1.custid),
    "left_anti",
)

display(df_old)

# COMMAND ----------

# everything thats been changed in source - left anti on source - inserts and updates - by checking hashkey for updates, cust_id for inserts

# union

# everything that remains the same - left anti on target

# COMMAND ----------

df_final1 = df_upsert.union(df_old)
display(df_final1)

# COMMAND ----------

df_final1.coalesce(1).write.mode("overwrite").option("header", "true").format("csv").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/target/")

# COMMAND ----------

spark.read.format("csv").option("header", "true").load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD1/target/").display()
# Databricks notebook source
# MAGIC %md
# MAGIC     day6: 27th-jan
# MAGIC       a) continue joins practice in pyspark and sql (left,left-anti,full-outer)
# MAGIC       b) read excel file in databricks 
# MAGIC       c) use case : create a function which gives count of records from each table present in SQL Server

# COMMAND ----------

# MAGIC %pip install com.crealytics:spark-excel_2.12:0.13.5

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC // Add the spark-excel library for Scala and Spark
# MAGIC spark.conf.set("spark.jars.packages", "com.crealytics:spark-excel_2.12:0.13.5")

# COMMAND ----------

# %pip install com.crealytics:spark-excel_2.12:0.13.5
from pyspark.sql.session import SparkSession
spark = SparkSession.builder \
    .appName("Excel Example") \
    .config("spark.jars.packages", "com.crealytics:spark-excel_2.12:0.13.5") \
    .getOrCreate()

df = spark.read \
  .format("com.crealytics.spark.excel") \
  .option("header", "true") \
  .load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/juicestores.xlsx")

display(df)


# COMMAND ----------

# MAGIC %pip install openpyxl
# MAGIC
# MAGIC # openpyxl is a powerful Python library used for reading, writing, and manipulating Excel files with the .xlsx format. It provides a wide range of functionality, from basic reading and writing to more advanced tasks like formatting cells, adding charts, and working with formulas.

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

import pyspark.pandas as pd
from pyspark.sql.types import StructType, StructField, StringType

pandasDf = pd.read_excel(
    "abfss://container@storageaccount.dfs.core.windows.net/tulasi/juicestores.xlsx",
    engine='openpyxl',
    sheet_name = 'Sheet1',
    dtype = str
)

pandasDf.display()

dtype_conversion = {
    'juice' : 'string',
    'store' : 'string'
}

pandasDf = pandasDf.astype(dtype_conversion)

sparkDf = pandasDf.to_spark()

display(sparkDf)

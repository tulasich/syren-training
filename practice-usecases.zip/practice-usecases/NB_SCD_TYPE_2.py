# Databricks notebook source
# MAGIC %md
# MAGIC       day7 28th-jan: 
# MAGIC         a) explore on SCD Type 2
# MAGIC         b) explore various options while writing df:
# MAGIC                 (1.overwriteSchema 2. mergeSchema)

# COMMAND ----------

# MAGIC %md
# MAGIC ### **`SCD TYPE 2`**
# MAGIC
# MAGIC Every time there is a change, we add a row to track the new values. 
# MAGIC
# MAGIC There are three flags implemented to track the history
# MAGIC
# MAGIC `From_date, To_date, Current_Flag`
# MAGIC
# MAGIC https://iterationinsights.com/article/how-to-implement-slowly-changing-dimensions-scd-type-2-using-delta-table/

# COMMAND ----------

# MAGIC %md
# MAGIC Merge into

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists adls.tulasi.therapist;
# MAGIC create table adls.tulasi.therapist(id int, patient_name string, gender string, fee double, therapist string, rating_of_patient int, therapist_remarks string, start_date timestamp, end_date timestamp, is_current string);
# MAGIC insert into adls.tulasi.therapist 
# MAGIC values (1, 'Snoop dog', 'Male', 10000, 'Obama', 4, 'Man doesnt think', '2001-09-11', NULL, 'Y'),
# MAGIC        (2, 'Elon musk', 'Male', 10000000, 'Mark', 1, 'ah....', '2022-04-14', NULL, 'Y'),
# MAGIC        (3, 'Xi Jinping', 'Male', 100000, 'Trump', 3, 'MAGA', '2009-01-20', '2019-01-01', 'N');

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from therapist

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists adls.tulasi.tales;
# MAGIC create table adls.tulasi.tales (id int, patient_name string, gender string, fee double, therapist string, rating_of_patient int, therapist_remarks string, start_date timestamp, end_date timestamp, is_current string);
# MAGIC insert into adls.gourinandan.tales
# MAGIC values (1, 'Snoop dog', 'Male', 10000, 'Drake', 4, 'Man thinks too deep', '2001-09-11', '2011-5-2', 'N'),
# MAGIC        (2, 'Elon musk', 'Male', 10000000, 'Mark', 1, 'Needs a real therapist', '2022-04-14', NULL, 'Y'),
# MAGIC        (3, 'Xi Jinping', 'Male', 100000, 'Trump', 3, 'Ban China', '2009-01-20', '2019-01-01', 'N'),
# MAGIC        (4, 'Zelenski', 'Male', 10, 'Putin', 9, 'Makes good jokes', '2000-09-11', NULL, 'Y'),
# MAGIC        (5, 'Billie Ellish', 'Female', 100000, 'Kanye', 2, 'Teens choice', '2011-09-11', '2011-09-21', 'N');

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tales

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into therapist T
# MAGIC using tales s
# MAGIC on T.id = s.id
# MAGIC and t.is_current = 'Y'
# MAGIC when matched and T.therapist <> s.therapist and T.therapist_remarks <> s.therapist_remarks and T.end_date <> s.end_date and T.is_current <> s.is_current then
# MAGIC update set T.end_date = CURRENT_DATE, T.is_current = 'No', T.therapist = s.therapist, T.therapist_remarks = s.therapist_remarks
# MAGIC when not matched then
# MAGIC insert (id, patient_name, gender, fee, therapist, rating_of_patient, therapist_remarks, start_date, end_date, is_current)
# MAGIC values (s.id, s.patient_name, s.gender, s.fee, s.therapist, s.rating_of_patient, s.therapist_remarks, s.start_date, s.end_date, s.is_current)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from therapist order by id

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history therapist

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from therapist
# MAGIC for version as of 1

# COMMAND ----------

# MAGIC %sql
# MAGIC create table therapist_version_1
# MAGIC select * from therapist
# MAGIC for version as of 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from therapist

# COMMAND ----------

scd_2_df = spark.sql("select * from adls.tulasi.therapist")

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC The Ralph Kimball Approach

# COMMAND ----------

# Libraries Needed for the demo
from delta.tables import *
from pyspark.sql.functions import *
from pyspark.sql.window import Window

gold_path = "abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD2/DimSales"
silver_path = "abfss://container@storageaccount.dfs.core.windows.net/tulasi/SCD/SCD2/updates"

# COMMAND ----------

data_g = [
    (100, 1, 200, 500, 800, "d43f…", "Y", "N", "2023-05-12", "2999-12-31"),
    (102, 6, 300, 900, 250, "214f…", "Y", "N", "2023-05-12", "2999-12-31"),
    (103, 13, 900, None, 700, "3c47…", "Y", "N", "2023-05-12", "2999-12-31"),
    (104, 43, 340, 359, 9032, "rc9f…", "Y", "N", "2023-05-12", "2999-12-31"),
]

columns = [
    "SurrogateKey",
    "DimId",
    "Col1",
    "Col2",
    "Col3",
    "Hash",
    "CurrentFlag",
    "DeletedFlag",
    "EffectiveFromDate",
    "EffectiveToDate",
]

# COMMAND ----------

columns = [
    "SurrogateKey",
    "DimId",
    "Col1",
    "Col2",
    "Col3",
    "Hash",
    "CurrentFlag",
    "DeletedFlag",
    "EffectiveFromDate",
    "EffectiveToDate",
]
data_s = [
    ("", "1", "200", "500", "800", "", "Y", "N", "2023-05-12", "2999-12-31"),
    ("", "6", "300", "900", "250", "", "Y", "N", "2023-05-12", "2999-12-31"),
    ("", "13", "100", None, "700", "", "Y", "N", "2023-06-08", "2999-12-31"),
    ("", "59", "1500", "2000", "800", "", "Y", "N", "2023-06-08", "2999-12-31"),
]

# COMMAND ----------

gold = spark.createDataFrame(data_g).toDF(*columns)
silver = spark.createDataFrame(data_s).toDF(*columns)

# COMMAND ----------

# Create hash for Col1, Col2 and Col3 using sha2 function with a bit length of 256

HashCols = ['Col1', 'Col2', 'Col3']
silver = silver.withColumn("Hash", lit(sha2(concat_ws("~", *HashCols), 256)))

# COMMAND ----------

# Keys for DimSales
keys = ['DimId', 'Hash']

# Build the dimension surrogate key
w = Window().orderBy(*keys)
silver = silver.withColumn("SurrogateKey", row_number().over(w))
silver = silver.withColumn("SurrogateKey",col("SurrogateKey").cast('long'))

# COMMAND ----------

# Write Dataframe as Delta Table (gold)
if not DeltaTable.isDeltaTable(spark, gold_path):
    gold.write.format("delta").mode("overwrite").save(gold_path)

# Write Dataframe as Delta Table (silver)
if not DeltaTable.isDeltaTable(spark, silver_path):
    silver.write.format("delta").mode("overwrite").save(silver_path)

# COMMAND ----------

condition = ['DimId', 'Hash', 'CurrentFlag', 'DeletedFlag']

RowsToUpdate = silver \
            .alias("source") \
            .where("CurrentFlag = 'Y' AND DeletedFlag = 'N'") \
            .join(gold.alias("target"),condition,'leftanti') \
            .select(*columns) \
            .orderBy(col('source.DimId')) 

# COMMAND ----------

# Retrieve maximum surrogate key in gold delta table
maxTableKey = DeltaTable.forPath(spark, gold_path).toDF().agg({"SurrogateKey":"max"}).collect()[0][0]

# COMMAND ----------

# Increment surrogate key in stage table by maxTableKey
RowsToUpdate = RowsToUpdate.withColumn("SurrogateKey", col("SurrogateKey") + maxTableKey)

# COMMAND ----------

# Merge statement to expire old records
DeltaTable.forPath(spark, gold_path).alias("original").merge(
    source = RowsToUpdate.alias("updates"),
    condition = 'original.DimId = updates.DimId'
).whenMatchedUpdate(
    condition = "original.CurrentFlag = 'Y' AND original.DeletedFlag = 'N' AND original.Hash <> updates.Hash",
    set = {                                      
        "CurrentFlag": "'N'",
        "EffectiveToDate": lit(current_timestamp())
    }
).execute()

# COMMAND ----------

spark.read.format("delta").load(gold_path).printSchema()


# COMMAND ----------

RowsToUpdate.select(*columns).printSchema()

# COMMAND ----------

RowsToUpdate = RowsToUpdate.withColumn("DimId", col("DimId").cast("long")) \
    .withColumn("Col1", col("Col1").cast("long")) \
    .withColumn("Col2", col("Col2").cast("long")) \
    .withColumn("Col3", col("Col3").cast("long")) 

# COMMAND ----------

# Insert all new and updated records
RowsToUpdate.select(*columns).write \
    .mode("append") \
    .format("delta") \
    .option("mergeSchema", "true") \
    .option("overwriteSchema", "true") \
    .save(gold_path)

# COMMAND ----------

RowsToDelete = gold.alias('gold').where("CurrentFlag = 'Y' AND DeletedFlag = 'N'") \
    .join(silver.alias('silver'), col('silver.DimId') == col('gold.DimId'), "leftanti")

# COMMAND ----------

# Merge statement to mark as deleted records
DeltaTable.forPath(spark, gold_path).alias("original").merge(
    source = RowsToDelete.alias("deletes"),
    condition = 'original.DimId = deletes.DimId'
).whenMatchedUpdate(
    condition = "original.CurrentFlag = 'Y' AND original.DeletedFlag = 'N'",
    set = {                                      
        "DeletedFlag": "'Y'",
        "EffectiveToDate": lit(current_timestamp())
    }
).execute()

# COMMAND ----------

spark.read.format("delta").load(gold_path).display()
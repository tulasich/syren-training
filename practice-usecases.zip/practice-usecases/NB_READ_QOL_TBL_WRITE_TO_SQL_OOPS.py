# Databricks notebook source
# LOOP THROUGH LIST OF COLUMN NAMES AND RENAME EACH COLUMN

# for col in qol_df.columns:
#     qol_df = qol_df.withColumnRenamed(col, col.replace(" ", "_"))

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, FloatType

qol_schema = StructType([
    StructField("country", StringType(), True),
    StructField("Purchasing Power Value", FloatType(), True),
    StructField("Purchasing Power Category", StringType(), True),
    StructField("Safety Value", FloatType(), True),
    StructField("Safety Category", StringType(), True),
    StructField("Health Care Value", FloatType(), True),
    StructField("Health Care Category", StringType(), True),
    StructField("Climate Value", FloatType(), True),
    StructField("Climate Category", StringType(), True),
    StructField("Cost_of Living Value", FloatType(), True),
    StructField("Cost of Living Category", StringType(), True),
    StructField("Property Price to Income Value", StringType(), True),
    StructField("Property Price to Income Category", StringType(), True),
    StructField("Traffic Commute Time Value", FloatType(), True),
    StructField("Traffic Commute Time Category", StringType(), True),
    StructField("Pollution Value", FloatType(), True),
    StructField("Pollution Category", StringType(), True),
    StructField("Quality of Life Value", StringType(), True),
    StructField("Quality of Life Category", StringType(), True)
])

qol_df = spark.read \
  .format("csv") \
  .option("header", "true") \
  .option("quote", "'") \
  .schema(qol_schema) \
  .load("abfss://container@storageaccount.dfs.core.windows.net/anusha/Quality_of_Life.csv")

d = {
    "country": "CNTRY",
    "Value" : "Val",
    "Category" : "Cat",
    " " : "_"
}

# Create a list of the new column names by replacing the dictionary keys with values
new_columns = []
for col in qol_df.columns:
    new_col = col
    for key, value in d.items():
        new_col = new_col.replace(key, value)  # Apply the replacement for each key-value pair
    new_columns.append(new_col)

# Rename the columns using the new column names
qol_df = qol_df.toDF(*new_columns)

display(qol_df)

# COMMAND ----------

from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
import random
from pyspark.sql.session import SparkSession

class Connection:
    def __init__(self):
        self.properties = {
            "host": "databaseName.database.windows.net",
            "user": dbutils.secrets.get("scope_tul", "username"),
            "password": dbutils.secrets.get("scope_tul", "password"),
            "database": "databaseName",
        }

class Transformations:
    def __init__(self, connection):
        self.connection = connection
        self.spark = SparkSession.builder.appName("AzureSQLTransformation").getOrCreate()

    def transformations(self, table_name):
        properties = self.connection.properties

        try:
            remote_table = (self.spark.read
                .format("sqlserver")
                .options(**self.connection.properties)
                .option("dbtable", table_name) # Use 'query' instead of 'dbtable'
                .load()
            )
        except Exception as e:
            print(f"Error connecting to database: {e}")

        def random_country():
            return random.choice(["India", "USA", "China", "Japan", "Germany", "France", "Italy", "Spain", "UK", "Canada"])

        random_country_udf = udf(random_country, StringType())

        remote_table = remote_table.withColumn("country", random_country_udf())

        display(remote_table)

        return remote_table

    def write(self, table_name):
        transformed_table = self.transformations(table_name)
        (transformed_table.write 
            .format("sqlserver")
            .options(**self.connection.properties)
            .option("dbtable", "[dbo].[new_table]") # (if schemaName not provided, default to "dbo")
            .mode("overwrite")
            .save()
        )

if __name__ == "__main__":
    conn = Connection()

    print(conn.properties)

    transform = Transformations(conn)
    transform.transformations("[dbo].[first]")
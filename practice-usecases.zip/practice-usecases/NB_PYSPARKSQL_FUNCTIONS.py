# Databricks notebook source
# MAGIC %md
# MAGIC     day 4:(23th-jan):-
# MAGIC       a)continue to explore on Azure Data factory (basics)
# MAGIC       b)explore on (what is SCD TYPE 1) and "databricks merge" Into command 
# MAGIC       C)continuation on pyspark sql functions like explode collect list, array joins etc etc ...
# MAGIC       (perform each function)

# COMMAND ----------

# MAGIC %md
# MAGIC ### **_`Pyspark SQL functions`_**

# COMMAND ----------

from pyspark.sql import functions as F

print(F.lit("Hello, World!"))

# COMMAND ----------

# MAGIC %md
# MAGIC **_pyspark.sql.functions.array_**

# COMMAND ----------

# name is string type
# lang_school and additional_language are arrays of strings - array type

data = [
    ("James,,Smith", ["Java","Scala","C++"], ["Python","PHP"], "CA"),
    ("Michael,Rose,", ["Spark","Java","C++"], ["AWS","Scala","Scala"], "NJ"),
    ("Robert,,Williams", ["AWS","Scala"], None, "NV")
    ]

df = spark.createDataFrame(data, ["name", "languages_school", "additional_language", "state"])

df.show()

# access the first element of array in the column

df \
    .select("languages_school") \
    .withColumn("first_value", F.col("languages_school")[0]).show()

# COMMAND ----------

data1 = [
  ("kit", "shark"),
  ("bless", "whale"),
  ("lara", "sea_turtle")
]

df1 = spark.createDataFrame(data1, ["name", "species"])

df1.show()

# join the two columns together to make an array

df1 \
  .withColumn("pearls", F.array("name", "species")) \
  .show()


df.display()

# COMMAND ----------

# pyspark.sql.functions.array_contains
# Returns true if the array contains the given value

df.where(F.array_contains(F.col("languages_school"), "C++")).show()

df.withColumn("haspython", F.array_contains(F.col("languages_school"), "Java")).show()

# COMMAND ----------

# pyspark.sql.functions.array_sort

df.withColumn("sorted_languages", F.array_sort(F.col("languages_school"))).show()

# COMMAND ----------

df2 = spark.createDataFrame([(["a", "b", "c"],), (["a", None],)], ['data'])
df2.select(F.array_join(df2.data, ",").alias("joined")).collect()

df2.select(F.array_join(df2.data, ",", "NULL").alias("joined")).show()


# COMMAND ----------

# MAGIC %md
# MAGIC     String to Array -> Split
# MAGIC     Array/List to Multiple rows -> Explode

# COMMAND ----------

# MAGIC %md
# MAGIC **_pyspark.sql.functions.explode_**

# COMMAND ----------

df.display()

df.withColumn("languages_school_exploded", F.explode("languages_school")).show()

exploded_df = df.select("name", F.explode("languages_school"), F.explode("additional_language"), "state")

exploded_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC **_pyspark.sql.functions.regexp_replace_**

# COMMAND ----------

exploded_cleaned_df = exploded_df.withColumn("name", F.regexp_replace(F.trim(F.regexp_replace(F.col("name"), ",", " ")), "  ", " "))
exploded_cleaned_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC **_pyspark.sql.functions.split_**

# COMMAND ----------

exploded_cleaned_df.withColumn("name", F.split(F.col("name"), " ")).show()

# COMMAND ----------

# from pyspark.sql import Row
# df = spark.createDataFrame([Row(a=1, intlist=[1,2,3], mapfield={"a": "b"})])
# df.select(F.explode(df.intlist).alias("anInt")).collect()

# COMMAND ----------

# MAGIC %md
# MAGIC **_pyspark.sql.functions.collect_**
# MAGIC
# MAGIC Returns all the records as a list of Row.

# COMMAND ----------

# MAGIC %md
# MAGIC .collect() Behavior:
# MAGIC
# MAGIC Return Type: It returns a list of Row objects, where each Row represents a row of the DataFrame.
# MAGIC
# MAGIC Structure: Each Row object is like a tuple, but it's actually a specialized object in Spark that behaves similarly to a tuple. You can access elements within each row using attribute access or by indexing.

# COMMAND ----------

collected_list = df.collect()

df.collect()

# returns a list - collected_df IS NOT A DATAFRAME

# COMMAND ----------

for row in collected_list:
    print(row[1])

# COMMAND ----------

# datatype casting collect list collect set explode_outer

# COMMAND ----------

# MAGIC %md
# MAGIC **_pyspark.sql.functions.join_**

# COMMAND ----------

rdf = (spark.read
       .format("delta")
       .table("adls.tulasi.runners"))

ro_df = (spark.read
.format("delta")
.table("adls.tulasi.runner_orders"))

# Inner join: Only matching rows from both DataFrames.
# Outer join: All rows from both DataFrames, with null where no match exists.
# Left join: All rows from the left DataFrame and matching rows from the right DataFrame.
# Right join: All rows from the right DataFrame and matching rows from the left DataFrame.
# Semi join: Rows from the left DataFrame that have a match in the right DataFrame (no right-side columns in result).
# Anti join: Rows from the left DataFrame that do not have a match in the right DataFrame.
# Cross join: Cartesian product of both DataFrames, with every row of the left DataFrame combined with every row of the right DataFrame.

rdf.join(ro_df, "runner_id", "inner").display()

rdf.join(ro_df, "runner_id", "outer").display()

rdf.join(ro_df, "runner_id", "left").display()

rdf.join(ro_df, "runner_id", "right").display()

rdf.join(ro_df, "runner_id", "semi").display()

rdf.join(ro_df, "runner_id", "anti").display()

rdf.join(ro_df, "runner_id", "cross").display()
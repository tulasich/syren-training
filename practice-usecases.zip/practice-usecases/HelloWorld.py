# Databricks notebook source
print("Hello, World")

# COMMAND ----------

# MAGIC  %fs ls abfss://container@storageaccount.dfs.core.windows.net/
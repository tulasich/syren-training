# Databricks notebook source
# MAGIC %md
# MAGIC Research and Small Implementation

# COMMAND ----------

for table in spark.catalog.listTables():
    print(table)

# COMMAND ----------

#  c) use case : create a function which gives count of records from each table present in SQL Server

def count_records(table_name):
    
    remote_table = (spark.read
        .format("sqlserver")
        .option("host", "databaseName.database.windows.net")
        .option("user", "username")
        .option("password", "password")
        .option("database", "databaseName")
        .option("dbtable", table_name) # (if schemaName not provided, default to "dbo")
        .load()
    )

    return remote_table.count()

count_records("[dbo].[CountryEconomy]")

# COMMAND ----------

# MAGIC %md
# MAGIC Actual usecase

# COMMAND ----------

# MAGIC %md
# MAGIC sqlserver

# COMMAND ----------

#  c) use case : create a function which gives count of records from each table present in SQL Server

def count_records():

    properties = {
        "host": "databaseName.database.windows.net",
        "user": "username",
        "password": "password",
        "database": "databaseName",
    }
    
    query = """
            SELECT table_schema, table_name 
            FROM information_schema.tables 
            WHERE table_type = 'BASE TABLE'
            """

    tables_names_df = (spark.read
        .format("sqlserver")
        .options(**properties) # dictionary unpacking
        .option("query", query) # Use 'query' instead of 'dbtable'
        .load()
    )

    tables_names_df.display()

    row_list = []

    for row in tables_names_df.collect():                                                      
        
        table_schema = row['table_schema']

        table_name = row['table_name']

        count_query = f"SELECT COUNT(*) AS count FROM {table_schema}.{table_name}"

        count_df = (spark.read
            .format("sqlserver")
            .options(**properties)
            .option("query", count_query) # Use 'query' instead of 'dbtable'
            .load()
        )
        

        count = count_df.collect()[0][0]

        row_list.append((table_schema, table_name, count))

    return spark.createDataFrame(row_list, ["TableSchema", "TableName", "Count"])
    
result_df = count_records()
result_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC jdbc

# COMMAND ----------

#  c) use case : create a function which gives count of records from each table present in SQL Server

def count_records():
    
    query = """
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_type = 'BASE TABLE'
            """

    table_names_df = (spark.read
        .format("jdbc")
        .option("url", "jdbc:sqlserver://databaseName.database.windows.net;databaseName=databseName")
        .option("user", "username")
        .option("password", "password")
        .option("query", query)
        .load()
    )

    for table in table_names_df.collect():
        table_name = table[0]
        count_query = f"SELECT COUNT(*) AS count FROM {table_name}"
        count_df = (spark.read
            .format("jdbc")
            .option("url", "jdbc:sqlserver://databaseName.database.windows.net;databaseName=databaseName")
            .option("user", "username")
            .option("password", "password")
            .option("query", count_query)
            .load()
        )
        count = count_df.collect()[0][0]
        print(f"Table: {table_name}, Count: {count}")

count_records()

# COMMAND ----------

# MAGIC %md
# MAGIC     Table: employee, Count: 1
# MAGIC     Table: CountryEconomy, Count: 50
# MAGIC     Table: Employee_2, Count: 25
# MAGIC     Table: email, Count: 24
# MAGIC     Table: CountryEconomy_v1, Count: 4
# MAGIC     Table: first_new, Count: 3
# MAGIC     Table: PipelineTracking, Count: 3
# MAGIC     Table: new, Count: 0
# MAGIC     Table: first, Count: 3

# COMMAND ----------

# MAGIC %md
# MAGIC scrap

# COMMAND ----------

# Install the ODBC Driver 17 for SQL Server
%pip install pyodbc

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

# JDBC connection properties
server = "databaseName.database.windows.net"
database = "databaseName"
username = "username"
password = "password"
jdbc_url = f"jdbc:sqlserver://{server}:1433;database={database}"

# JDBC connection options
connection_properties = {
    "user": username,
    "password": password,
    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"
}

# Query to get all table names
query = """
SELECT table_name 
FROM information_schema.tables 
WHERE table_type = 'BASE TABLE'
"""

# Use Spark to read the data
table_names_df = spark.read.jdbc(url=jdbc_url, table=f"({query}) as tables", properties=connection_properties)

# Show table names
table_names_df.show()

# Loop through table names if needed
table_names = [row['table_name'] for row in table_names_df.collect()]
for table in table_names:
    print(f"Table: {table}")

# COMMAND ----------

# MAGIC %md
# MAGIC     +-----------------+
# MAGIC     |       table_name|
# MAGIC     +-----------------+
# MAGIC     |         employee|
# MAGIC     |   CountryEconomy|
# MAGIC     |       Employee_2|
# MAGIC     |            email|
# MAGIC     |CountryEconomy_v1|
# MAGIC     |        first_new|
# MAGIC     | PipelineTracking|
# MAGIC     |              new|
# MAGIC     |            first|
# MAGIC     +-----------------+
# MAGIC
# MAGIC     Table: employee
# MAGIC     Table: CountryEconomy
# MAGIC     Table: Employee_2
# MAGIC     Table: email
# MAGIC     Table: CountryEconomy_v1
# MAGIC     Table: first_new
# MAGIC     Table: PipelineTracking
# MAGIC     Table: new
# MAGIC     Table: first
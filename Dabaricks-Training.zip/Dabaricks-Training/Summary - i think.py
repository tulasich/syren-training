# Databricks notebook source
# MAGIC %md
# MAGIC Why Databricks is cool?
# MAGIC
# MAGIC There's Delta lake
# MAGIC
# MAGIC This guys an open source "storage layer" that provides relational database semantics to Spark - can be used to be a part of another really cool guy - data lakehouse. ACID properties on data lake are provided by delta lake. He's just parquet under the hood but with mods! Safe, not messy and Awesome.
# MAGIC
# MAGIC
# MAGIC https://delta.io/blog/delta-lake-vs-data-lake/
# MAGIC
# MAGIC For example, suppose you’re writing a large amount of data to an existing data lake of Parquet files. If your cluster dies during the operation, you may be left with partially written Parquet files in your data lake. These partial files will break downstream reads. To fix this, you will need to identify all of the corrupted files and delete them. You will then need to re-run the operation and hope that your cluster won’t die again. Not fun.
# MAGIC
# MAGIC This kind of situation is not possible with ACID transactions: the entire write operation will fail and you will be free to retry without having to deal with a corrupted table.

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Metastore - centralized repository that stores metadata about the data in your data lake or warehouse.
# MAGIC
# MAGIC Key Functions of the Databricks Metastore:
# MAGIC 1. Schema Management: It keeps track of the schemas (tables, columns, types) for datasets.
# MAGIC 2. Data Partitioning: It manages partitioning information for large datasets, which can improve query performance.
# MAGIC 3. Optimized Storage: The Metastore improves data storage by enabling optimized file formats (like Delta), and indexing metadata to speed up queries.
# MAGIC 4. Versioning: It supports historical versions of tables through Delta Lake’s time travel feature, allowing you to access previous versions of data.

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

spark.sql("show tables in adls.tulasi").show()

# COMMAND ----------

spark.sql("describe customer_orders").show()

# COMMAND ----------


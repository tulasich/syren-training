# Databricks notebook source
# MAGIC %md
# MAGIC In this notebook,
# MAGIC reading and tranforming and saving files as tables of different formats.
# MAGIC <br>
# MAGIC partitionby syntax and understanding

# COMMAND ----------

# Load data

df = spark.read.load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.csv", format = "csv", header = "true", inferSchema = "true")

# COMMAND ----------

df.display()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from adls.tulasi.sample

# COMMAND ----------

# creating a temporary view within the session

df.createOrReplaceTempView("sample_view")

# using spark.sql method for inline sql queries that return a dataframe

sample_df  = spark.sql ("select case when gender ilike '%f%' then 'Female' when gender ilike '%m%' then 'Male' else 'Other' end as gender, \
                                count(case when work_interfere IN ('Often', 'Rarely', 'Sometimes') then 1 else null end) as work_interfere_count  \
                        from sample_view \
                        where gender is not null and work_interfere is not null \
                        GROUP BY gender")

display(sample_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Modify and save dataframes
# MAGIC
# MAGIC - Load source file into a dataframe
# MAGIC - Use dataframe methods and functions to transform the data:
# MAGIC     - Filter rows
# MAGIC     - Modify column values
# MAGIC     - Derive new columns
# MAGIC     - Drop columns
# MAGIC
# MAGIC - Write the modified data
# MAGIC     - Specify required file format

# COMMAND ----------

from pyspark.sql.functions import year, col

# Load data
df = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .table("adls.tulasi.sample")

# Add Some Column

add_col_df = df.withColumn("Year", year(col("Timestamp")))

# Save transformed data

add_col_df.write.mode("overwrite").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.parquet")

# COMMAND ----------

df.write.partitionBy("Year").saveAsTable("transformed_sample", format = "parquet", mode = "overwrite", path="abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.parquet")

# COMMAND ----------

spark.sql("show tables in adls.tulasi").show()

# COMMAND ----------

spark.read.parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.parquet").display()

# COMMAND ----------

# MAGIC %sql
# MAGIC create table adls.tulasi.test;

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables

# COMMAND ----------

# MAGIC %sql
# MAGIC use adls.tulasi

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables

# COMMAND ----------

# MAGIC %sql
# MAGIC -- drop table sample_transformed
# MAGIC -- drop table test
# MAGIC show tables

# COMMAND ----------

spark.sql("show tables in adls.tulasi").show()

# COMMAND ----------

# recap - best format for analytical data processing is parquet

add_col_df.write.partitionBy("Year").mode("overwrite").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.parquet")

# COMMAND ----------

display(add_col_df)

# COMMAND ----------

add_col_df.explain()

# COMMAND ----------

# MAGIC %sql
# MAGIC create table source_adls.default.sample_external()

# COMMAND ----------

# MAGIC %sql
# MAGIC show external locations

# COMMAND ----------

ex_df = spark.read.format("csv").load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.csv")

# COMMAND ----------

ex_df.explain()

# COMMAND ----------

# Ensure ex_df is properly initialized
ex_df = spark.read.format("delta").load("path_to_your_data")

# Write the DataFrame to a Delta table
ex_df.write.mode("overwrite").format("delta").saveAsTable("abfss://.dfs.core.windows.net/tulasi/sampleuuu")

# COMMAND ----------

# DBTITLE 1,external table
# MAGIC %sql
# MAGIC CREATE TABLE external_table
# MAGIC USING PARQUET
# MAGIC OPTIONS (
# MAGIC   'path' 'abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.parquet'
# MAGIC );
# MAGIC

# COMMAND ----------


spark.sql("CREATE SCHEMA IF NOT EXISTS source_adls.tulasi")

# COMMAND ----------

spark.sql("describe source_adls.default.")

# COMMAND ----------

# MAGIC %sql
# MAGIC describe adls.tulasi.pickles

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC describe extended adls.tulasi.pickles

# COMMAND ----------

# DBTITLE 1,checking access to external locations
# MAGIC %sql
# MAGIC show grant on external location source_adls

# COMMAND ----------

spark.sql("show tables in adls.tulasi").show()

# COMMAND ----------

pickel_df = spark.read.format("csv").option("header", True).option("inferSchema", True).table("adls.tulasi.pickles")

# COMMAND ----------

from pyspark.sql.functions import rand, floor, col
from pyspark.sql.types import IntegerType

max_year = 3024
min_year = 1990

pickles_years_df = pickel_df.withColumn("Year", (floor(rand() * (max_year - min_year + 1)) + min_year).cast(IntegerType()))


# COMMAND ----------

pickles_years_df.display()

# COMMAND ----------

from pyspark.sql import Row

new_rows = [Row(id=3, name='sourpickel', Year=2020), Row(id=4, name='peanut', Year=2019), Row(id=5, name='Fig', Year=1988)]
new_rows_df = spark.createDataFrame(new_rows)

pickles_years_df = pickles_years_df.union(new_rows_df)
display(pickles_years_df)

# COMMAND ----------

pickles_years_df = pickles_years_df.limit(5)

# COMMAND ----------

display(pickles_years_df)

# COMMAND ----------

pickles_years_df.write.partitionBy("Year").parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/pickles_years.parquet")

# COMMAND ----------

pickels_parquet_df = spark.read.parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/pickles_years.parquet")

# COMMAND ----------

display(pickels_parquet_df)

# COMMAND ----------

pickels_parquet_df.write.saveAsTable("adls.tulasi.pickles_years_parquet")

# COMMAND ----------

spark.sql("show tables in adls.tulasi").show()

# COMMAND ----------

pickels_parquet_df.printSchema()

# COMMAND ----------

spark.read.parquet("abfss://container@storageaccount.dfs.core.windows.net/tulasi/pickles_years.parquet/Year=2020").show()

# Databricks notebook source
# MAGIC %md
# MAGIC Tables Managed & External

# COMMAND ----------

# MAGIC %md
# MAGIC show tables - sql command
# MAGIC
# MAGIC List all tables in the current database/schema
# MAGIC spark.sql("SHOW TABLES").show()
# MAGIC
# MAGIC ##### List all tables (including temporary tables) in the current session
# MAGIC tables = spark.catalog.listTables()
# MAGIC `for table in tables:
# MAGIC     print(f"Table Name: {table.name}, Type: {table.tableType}") `

# COMMAND ----------

# MAGIC %md
# MAGIC unfortunately, cannot create external tables - managed only <br>
# MAGIC also, fetching tables from external location is disabled, however, creating a table on catalog and copying from the abfss location is possible

# COMMAND ----------

"abfss://s.core.windows.net/tulasi/__unitystorage/schemas/55db10d4-b7ce-43be-b1c1-a6a13aaa6358/tables/e95727e3-125f-4d5f-9b1d-e458749dc7e5"

# COMMAND ----------

df = spark.read.csv("abfss://source@internsstorage1.dfs.core.windows.net/tulasi/sample.csv", header = True, inferSchema = True)

# Save DataFrame as a Managed Delta Table
#df.saveAsTable("adls.tulasi.my_managed_delta_table")
df.display()

# COMMAND ----------

df.write.saveAsTable("adls.tulasi.my_managed_delta_table")

# COMMAND ----------

# Verify by running a SQL query on the table
# spark.sql("SELECT * FROM my_managed_delta_table").show()


# COMMAND ----------

# MAGIC %sql
# MAGIC use adls.tulasi;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table runners;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table sample

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists pickles (id int, name string);
# MAGIC
# MAGIC insert into pickles values (1, "mango"), (2, "lemon")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from adls.tulasi.pickles

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables

# COMMAND ----------

# List all tables in the current database/schema
# spark.sql("SHOW TABLES").show()

# List all tables (including temporary tables) in the current session
tables = spark.catalog.listTables()
for table in tables:
    print(f"Table Name: {table.name}, Type: {table.tableType}")



# COMMAND ----------

# MAGIC %sql
# MAGIC use adls.tulasi;

# COMMAND ----------

spark.sql("SHOW TABLES").show()

# COMMAND ----------

tables = list(tables)

# COMMAND ----------

for table in tables:
    print(table, table.tableType)

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables in tulasi

# COMMAND ----------

# MAGIC %sql describe table tulasi.pickles

# COMMAND ----------

file_path = 'abfss://source@internsstorage1.dfs.core.windows.net/tulasi'

# COMMAND ----------

# MAGIC %sql
# MAGIC use adls.tulasi

# COMMAND ----------

tables = spark.catalog.listTables()
for table in tables:
    print(table.name, table.tableType)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- GRANT CREATE EXTERNAL TABLE ON EXTERNAL LOCATION source_adls TO `tulasi.c@syrencloud.com`;

# COMMAND ----------

# MAGIC %sql
# MAGIC create table adls.tulasi.my_external_table
# MAGIC using parquet
# MAGIC location "abfss://source@internsstorage1.dfs.core.windows.net/tulasi/sample.parquet"

# COMMAND ----------


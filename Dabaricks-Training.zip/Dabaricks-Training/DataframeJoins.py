# Databricks notebook source
print("run")

# COMMAND ----------

print("i hate my life")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Types of joins
# MAGIC Inner - Values same in both dfs <br>
# MAGIC Left Outer - Values that match + left records - and null in place of unmatched records <br>
# MAGIC Right Outer - Values that match + right records - and null in place of unmatched records <br>
# MAGIC Full Outer - All Values (A full outer join returns all rows from both tables, including matched rows based on the join condition, and rows without matches will have NULL values for the missing side.)<br>
# MAGIC Left Anti - Values that match rejected and unmatched left records returned<br>
# MAGIC Left Semi - On the values that match ONLY left columns & records are returned<br>
# MAGIC
# MAGIC df1.join(df2, df1.column_name = df2.column_name, "join_type")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Types of Joins (Backend)
# MAGIC - Broadcast Join
# MAGIC   - in the partitions, the df2 which is small is put inside the partitions, which consists of parts of df1 - which is a bigger table. so, no shuffle in this process
# MAGIC   - table >1gb can be considered big table, <500mb small
# MAGIC - Sort Merge Join
# MAGIC   - table divided to partitions - both df1 and df2 - match - shuffle - sort - merge
# MAGIC - Shuffle Hash Join
# MAGIC
# MAGIC #### Unions of dfs
# MAGIC unioned_df = df1.union(df2)

# COMMAND ----------

print("i love my life")

# COMMAND ----------

print("lol")

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType

dataemplyee = [
    ("James","", "Smith", "26636","M",111),
    ("Michael", "Rose","","42288","M",222),
    ("Robert", "", "Williams","47114","M",333),
    ("Maria", "Anne", "Jones","12192","F",111),
    ("Jen", "Mary", "Brown","", "F",222),
    ("Jas","", "Smith","36634","M",111),
    ("Mike", "Rose","", "40299","M",222),
    ("Roby","","Williams","42156","M",333),
    ("Mary", "Anne", "Jones", "30002", "F",111),
    ("Ben", "Mary", "Brown", "12345","F",222),
    ("Mike2", "Rose","","48299","M",2),
    ("Roby2","", "Williams","42156","M",3),
]

schemaemp = StructType([
    StructField("firstname", StringType(), True),
    StructField("middlename", StringType(), True),
    StructField("lastname", StringType(), True),
    StructField("id", StringType(), True),
    StructField("gender", StringType(), True),
    StructField("dep_id", IntegerType(), True)
])

# COMMAND ----------


datadep = [ (111,"HR", "Block1A"),
            (222,"Finance", "Block2A"),
            (333, "Software", "BLock3A"),
            ]
schemadep = StructType([
                StructField("dep_id", IntegerType(), True),
                StructField("dep_name", StringType(), True),
                StructField("block",StringType(),True),
            ])

# COMMAND ----------

emp_df = spark.createDataFrame(dataemplyee, schemaemp)
dep_df = spark.createDataFrame(datadep, schemadep)

# COMMAND ----------

emp_df.write \
    .option("header", "true") \
    .format("csv") \
    .mode("overwrite") \
    .save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/emps")
dep_df.write \
    .format("csv") \
    .option("header", "true") \
    .mode("overwrite") \
    .save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/depts")

# COMMAND ----------

df = spark.read.load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/emps", format="csv", header="true")

# COMMAND ----------

df.display()

# COMMAND ----------

emp_df.display()
dep_df.display()

# COMMAND ----------

inner_join_df = emp_df.join(dep_df, emp_df.dep_id == dep_df.dep_id, 'inner')
inner_join_df.display()

# COMMAND ----------

left_join_df = emp_df.join(dep_df, emp_df.dep_id == dep_df.dep_id, 'left')
left_join_df.display()

# COMMAND ----------

right_join_df = emp_df.join(dep_df, emp_df.dep_id == dep_df.dep_id, 'right')
right_join_df.display()

# COMMAND ----------

full_outer_join_df = emp_df.join(dep_df, emp_df.dep_id == dep_df.dep_id, 'full')
full_outer_join_df.display()

# COMMAND ----------

left_anti_df = emp_df.join(dep_df, emp_df.dep_id == dep_df.dep_id, 'anti')
left_anti_df.display()

# COMMAND ----------

left_semi_df = emp_df.join(dep_df, emp_df.dep_id == dep_df.dep_id, 'semi')
left_semi_df.display()

# COMMAND ----------

left_join_df.explain()

# COMMAND ----------

right_join_df.explain(extended=True)

# COMMAND ----------

print("great")

# COMMAND ----------

# MAGIC %sql
# MAGIC use interns_adls.tulasi

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table employees

# COMMAND ----------

emp_df.write.format("delta").mode("overwrite").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/employees")

# COMMAND ----------

emp_df.write.format("parquet").mode("overwrite").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/employees_parquet")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table employees

# COMMAND ----------

# MAGIC %sql
# MAGIC use interns_adls.tulasi

# COMMAND ----------

tables = spark.catalog.listTables()
for table in tables:
    print(table.name, table.tableType)

# COMMAND ----------

# MAGIC %sql
# MAGIC create external table interns_adls.tulasi.employees
# MAGIC using delta
# MAGIC location 'abfss://container@storageaccount.dfs.core.windows.net/tulasi/employees'

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table pickles_years_parquet

# COMMAND ----------

# MAGIC %sql
# MAGIC create external table interns_adls.tulasi.employees_parquet
# MAGIC using parquet
# MAGIC location 'abfss://container@storageaccount.dfs.core.windows.net/tulasi/employees_parquet'

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create external table interns_adls.tulasi.sample_csv
# MAGIC using csv
# MAGIC location 'abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.csv'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from interns_adls.tulasi.employees

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table depts

# COMMAND ----------

dep_df.write.format("delta").saveAsTable("interns_adls.tulasi.depts")

# COMMAND ----------

spark.read.format("csv").load("abfss://syren@internsstorage1.dfs.core.windows.net/tulasi/__unitystorage/schemas/sample.csv").show()

# COMMAND ----------

dbutils.fs.ls('abfss://container@storageaccount.dfs.core.windows.net/tulasi/')

# COMMAND ----------

# MAGIC %sql
# MAGIC select id

# COMMAND ----------

emp_df.write.saveAsTable("interns_adls.tulasi.employees")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table employees

# COMMAND ----------

emp_df.write.format("delta").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/employees")

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC create table interns_adls.tulasi.employees
# MAGIC using delta
# MAGIC location "abfss://container@storageaccount.dfs.core.windows.net/tulasi/employees"

# COMMAND ----------

# MAGIC %sql
# MAGIC use interns_adls.tulasi

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Use the appropriate database
# MAGIC USE interns_adls.tulasi;
# MAGIC
# MAGIC -- Create the external table
# MAGIC CREATE TABLE IF NOT EXISTS pickles
# MAGIC USING DELTA
# MAGIC LOCATION 'abfss://container@storageaccount.dfs.core.windows.net/tulasi/pickles';
# MAGIC
# MAGIC -- Insert data from the source table into the new table
# MAGIC INSERT INTO pickles
# MAGIC SELECT * FROM interns_adls.tulasi.pickles;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM pickles;

# COMMAND ----------

# MAGIC %fs ls abfss://container@storageaccount.dfs.core.windows.net/gourinandan/

# COMMAND ----------

dep_df.write.format("parquet").save("abfss://container@storageaccount.dfs.core.windows.net/tulasi/departments_parquet")

# COMMAND ----------

spark.read.format("parquet").load("abfss://container@storageaccount.dfs.core.windows.net/gourinandan/Products.parquet/").display()

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE interns_adls.tulasi.ztv
# MAGIC USING delta
# MAGIC LOCATION 'abfss://container@storageaccount.dfs.core.windows.net/gourinandan/Products.parquet/'

# COMMAND ----------

CREATE EXTERNAL TABLE interns_adls.tulasi.etv
USING delta
LOCATION 'abfss://container@storageaccount.dfs.core.windows.net/sivakrishna/'
AS SELECT * FROM parquet.`abfss://container@storageaccount.dfs.core.windows.net/sivakrishna/file.parquet`

# COMMAND ----------

# MAGIC %sql
# MAGIC create external table interns_adls.tulasi.gemini
# MAGIC using delta
# MAGIC location 'abfss://container@storageaccount.dfs.core.windows.net/tulasi/departments_parquet'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from databricksforinterns.default.employee_view

# COMMAND ----------

emp_df.display()

# COMMAND ----------

emp_df.printSchema()

# COMMAND ----------

from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

def add_dollar_sign(value):
    return '$' +  value

# COMMAND ----------

add_dollar_sign_udf = udf(add_dollar_sign, StringType())

# COMMAND ----------

emp_df.withColumn("salary", add_dollar_sign_udf(emp_df["id"])).display()

# COMMAND ----------

tables = spark.catalog.listTables()

# COMMAND ----------

for table in tables:
    print(table.name + " " + table.type)

# COMMAND ----------

# MAGIC %sql
# MAGIC use interns_adls.tulasi

# COMMAND ----------

tables = spark.catalog.listTables()
for table in tables:
    print(table.name, table.format)

# COMMAND ----------

emp_df.write.format("delta").saveAsTable("interns_adls.tulasi.emp_delta")

# COMMAND ----------

emp_delta_df = spark.table("emp_delta")

# COMMAND ----------

emp_delta_df.display()

# COMMAND ----------


# Databricks notebook source
# MAGIC %md
# MAGIC #### Window functions
# MAGIC
# MAGIC ##### Spark Window functions are used to calculate results such as the rank, row number, lead, lag etc over a range of input rows
# MAGIC ##### Spark Window functions operate on a group of rows (like frame, partition) and return a single value for every input row. Spark SQL supports three kinds of window functions:
# MAGIC #
# MAGIC - ranking functions
# MAGIC - analytic functions
# MAGIC - aggregate functions
# MAGIC
# MAGIC Terms such as Windowing / partition / bucketing are used interchangeably
# MAGIC
# MAGIC To use window functions, Syntax ->
# MAGIC
# MAGIC from pyspark.sql.window import Window
# MAGIC
# MAGIC ``windowSpec = Window.partitionBy(columnname).orderBy(columnname).desc``
# MAGIC
# MAGIC ``df.withColumn("newcolumnname", windowfunction("colname").over(windowspec)).show()``
# MAGIC
# MAGIC lead, lag, rank, dense_rank, ntile
# MAGIC

# COMMAND ----------

print("i hate my life day 2")
print("not so much i think")

# COMMAND ----------

print("cool")

# COMMAND ----------

spark.sql("select * from adls.tulasi.employees").show()

# COMMAND ----------

emp_df.printSchema()

# COMMAND ----------

# %python
# # Enable column mapping on the Delta table
# spark.sql("""
# ALTER TABLE adls.tulasi.employees 
# SET TBLPROPERTIES (
#     'delta.minReaderVersion' = '2', 
#     'delta.minWriterVersion' = '5', 
#     'delta.columnMapping.mode' = 'name'
# )
# """)

# # Rename the column after enabling column mapping
# spark.sql("ALTER TABLE adls.tulasi.employees RENAME COLUMN id TO salary")

# COMMAND ----------

emp_df.show()

# COMMAND ----------

emp_df = spark.read.table("adls.tulasi.employees")
dep_df = spark.read.table("adls.tulasi.depts")

# COMMAND ----------

emp_df.display()
dep_df.display()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import lag, lead, rank

windowspec = Window.partitionBy("gender").orderBy("salary")

# df.withColumn("newcolumnname", windowfunction("colname").over(windowspec)).show()

emp_df.withColumn("lead", lead("salary",1).over(windowspec)).show()

# COMMAND ----------


# Databricks notebook source
# MAGIC %fs ls abfss://container@storageaccount.dfs.core.windows.net/tulasi/

# COMMAND ----------

# Set up the necessary configurations for accessing Azure Data Lake Storage

sample_df = spark.read.format("csv") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .load("abfss://container@storageaccount.dfs.core.windows.net/tulasi/sample.csv")

display(sample_df)

# COMMAND ----------


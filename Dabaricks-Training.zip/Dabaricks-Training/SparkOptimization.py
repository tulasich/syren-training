# Databricks notebook source
# MAGIC %md
# MAGIC #### catalyst optimizer
# MAGIC
# MAGIC catalyst optimizer is at core of spark sql build in Scala. It helps to add new optimization features or modify the existing one.
# MAGIC
# MAGIC Works on tree based algorithm.
# MAGIC
# MAGIC Supports both Cost based and Role based optimization.
# MAGIC
# MAGIC i think i hate it

# COMMAND ----------

# MAGIC %md
# MAGIC SQL Query/Dataframe -> 
# MAGIC
# MAGIC Unresolved Logical Plan <-> Catalog (Schema is checked) ->
# MAGIC <br> (Syntax and Semantic Checking)
# MAGIC
# MAGIC Logical Plan
# MAGIC
# MAGIC Optimized Logical Plan
# MAGIC
# MAGIC Physical plan
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Scope of optimization
# MAGIC
# MAGIC Reduce the Network I/O
# MAGIC
# MAGIC Reduce Disk I/O
# MAGIC Improve/optimize CPU utilization by reducing any unnecessary computation, including filtering out unnecessary data, and ensuring that your CPU resources are getting utilized efficiently
# MAGIC Benefit from Spark's in-memory computation, including caching when appropriate
# MAGIC Revisit Spark Characteristics to help in performance
# MAGIC 1. Lazy evaluation
# MAGIC 2. File Formats
# MAGIC 3. Parallelism
# MAGIC 4. Reduce Shuffle
# MAGIC 5. Filter
# MAGIC 6. Cache when needed
# MAGIC 7. Join operations
# MAGIC 8. Tune cluster resources
# MAGIC 9. Avoid costly operations
# MAGIC 10. Data Skew
# MAGIC 11. UDF

# COMMAND ----------

# MAGIC %md
# MAGIC ### Repartition and Coalesce
# MAGIC
# MAGIC Partition is the key for performance (as distributed parallel framework)
# MAGIC So need to choose right number of partition and right size of partition
# MAGIC
# MAGIC Partition
# MAGIC For example we have 10 cores and only 6 partitions, then 4 cores are idle
# MAGIC
# MAGIC Very clear that partitions should be multiple of cores
# MAGIC
# MAGIC Imagine 2 cores working on 2 different size of data (one with smaller size will remain idele while other core is busy)
# MAGIC
# MAGIC Default the number of partitions is 8 and default partition bytes is 128MB (reconfigurable. Though)
# MAGIC
# MAGIC Remember files in compressed form can't be split.
# MAGIC
# MAGIC The parameters which is used in spark for the above purpose is
# MAGIC
# MAGIC Spark.sql.files.maxpartitionbytes
# MAGIC
# MAGIC sc.defaultparallelism

# COMMAND ----------

emp_df = spark.read.format("delta").table("adls.tulasi.employees")

# COMMAND ----------

display(emp_df)

# COMMAND ----------

from pyspark.sql.functions import col, upper, concat_ws
assignment_df = emp_df.drop("middlename")

assignment_df = assignment_df.withColumn("firstname", upper(col("firstname")))

assignment_df = assignment_df.withColumnRenamed("dep_id", "d_id").withColumnRenamed("gender", "sex")

assignment_df = assignment_df.withColumn("fullname", concat_ws(" ", col("firstname"), col("lastname")))

assignment_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Cache and Persist
# MAGIC
# MAGIC #### Cache
# MAGIC
# MAGIC when "exchange" written on dag - shuffling
# MAGIC
# MAGIC

# COMMAND ----------

print("i hate my life day 4")

# COMMAND ----------

rdd = emp_df.rdd

# COMMAND ----------

emp_df.rdd.getNumPartitions()

# COMMAND ----------

type(emp_df)

# COMMAND ----------

# MAGIC %md
# MAGIC i really really really hate partitions concept like really hate it : spark optimization also
# MAGIC
# MAGIC i dont even want to describe my hatred towards it. ill skip this for now - not to mention rdd is not implemented on this databricks accuont. so like what's the point, really, overall? is it even useful
# MAGIC
# MAGIC i skip for now anyway.

# COMMAND ----------


# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import dense_rank

# COMMAND ----------

# create sales data
sales_data = [
          ('A', '2021-01-01', '1'),
          ('A', '2021-01-01', '2'),
          ('A', '2021-01-07', '2'),
          ('A', '2021-01-10', '3'),
          ('A', '2021-01-11', '3'),
          ('A', '2021-01-11', '3'),
          ('B', '2021-01-01', '2'),
          ('B', '2021-01-02', '2'),
          ('B', '2021-01-04', '1'),
          ('B', '2021-01-11', '1'),
          ('B', '2021-01-16', '3'),
          ('B', '2021-02-01', '3'),
          ('C', '2021-01-01', '3'),
          ('C', '2021-01-01', '1'),
          ('C', '2021-01-07', '3')]
# cols
sales_cols= ["customer_id", "order_date", "product_id"]

sales_df = spark.createDataFrame(data = sales_data, schema = sales_cols)

# view the data
sales_df.show()


# COMMAND ----------

# menu data
menu_data = [ ('1', 'palak_paneer', 100),
              ('2', 'chicken_tikka', 150),
              ('3', 'jeera_rice', 120),
              ('4', 'kheer', 110),
              ('5', 'vada_pav', 80),
              ('6', 'paneer_tikka', 180)]
# cols
menu_cols = ['product_id', 'product_name', 'price']
# create the menu dataframe
menu_df = spark.createDataFrame(data = menu_data, schema = menu_cols)
# view the data
menu_df.show()

# COMMAND ----------

# create member data
members_data = [ ('A', '2021-01-07'),
                 ('B', '2021-01-09')]
# cols
members_cols = ["customer_id", "join_date"]
# create the member's dataframe
members_df = spark.createDataFrame(data = members_data, schema = members_cols)
# view the data
members_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC What is the total amount each customer spent at the restaurant?

# COMMAND ----------

total_spent_df = (
    sales_df.join(menu_df, "product_id")
    .groupBy("customer_id")
    .agg({"price": "sum"})
    .withColumnRenamed("sum(price)", "total_spent_amounts")
    .orderBy("customer_id")
)

total_spent_df.display()

# COMMAND ----------

sales_df.groupBy("customer_id") \
    .agg(F.countDistinct("order_date")) \
    .display()

# COMMAND ----------

# MAGIC %md
# MAGIC What was each customer’s first item from the menu?

# COMMAND ----------

sales_df.join(menu_df, "product_id") \
    .withColumn("dense_rank", dense_rank().over(Window.partitionBy("customer_id").orderBy("order_date"))) \
    .select("customer_id", "product_name") \
    .filter("dense_rank == 1") \
    .display()

# COMMAND ----------

sales_df.join(menu_df, "product_id") \
    .groupBy("product_name").count().orderBy("count", ascending=False).limit(1).display()

# COMMAND ----------

total_orders = (
    sales_df.join(menu_df, "product_id")
    .groupBy("customer_id", "product_name")
    .agg(F.count("product_id").alias("total_orders"))
)

total_orders_with_rank = total_orders.withColumn(
    "rank",
    dense_rank().over(
        Window.partitionBy("customer_id").orderBy(F.desc("total_orders"))
    ),
)

total_orders_with_rank.select("customer_id", "product_name") \
    .filter("rank == 1").display()

# COMMAND ----------


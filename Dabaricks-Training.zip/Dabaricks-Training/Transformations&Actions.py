# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType, IntegerType # type imports for schema definition

data2 = [("James","", "Smith","36636","M"),
    ("Michael", "Rose","", "40288","M"),
    ("Robert","", "Williams","42114","M"),
    ("Maria","Anne", "Jones","39192","F"),
    ("Jen", "Mary", "Brown","", "F"),
    ("adam","", "Smith","36636","M"),
    ("eve", "Rose","", "40288","M"),
    ("Robert","", "Williams","42114","M"),
    ("alia","Anne", "Jones","39192","F"),
    ("gin", "Mary", "Brown","", "F")
]

schema = StructType([ \
    StructField("firstname", StringType(), True), \
    StructField("middlename", StringType(), True), \
    StructField("lastname", StringType(), True), \
    StructField("id", StringType(), True), \
    StructField("gender", StringType(), True), \
])

df = spark.createDataFrame(data=data2, schema=schema)
df.display()

# COMMAND ----------

# Print the number of partitions
# print("Partitions: " + str(df.rdd.getNumPartitions())) - rdd is disabled

df.explain(True)

# COMMAND ----------

# csvDF = (spark.read
#          .option("header", "true")
#          .option("sep", "\t")
#          .schema(csvSchema)
#          .csv(csvFile)
#         )

# print("Partitions: " + str(csvDF.rdd.getNumPartitions()))


# COMMAND ----------

#sort based on gender

df.sort("gender").display()

# COMMAND ----------

df.filter(df.id > 40000).display()

# COMMAND ----------

df.groupBy("gender", "id").count().display()

# COMMAND ----------


# Databricks notebook source
# MAGIC %md
# MAGIC ## dbutils 
# MAGIC ### fs

# COMMAND ----------

dbutils.help()

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

file_path = 'abfss://container@storageaccount.dfs.core.windows.net/tulasi'

# COMMAND ----------

dbutils.fs.ls(file_path)

# COMMAND ----------

dbutils.fs.mkdirs('abfss://container@storageaccount.dfs.core.windows.net/tulasi/temp/')

# COMMAND ----------



# COMMAND ----------

